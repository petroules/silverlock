﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using System;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Globalization;
    using System.Windows.Forms;
    using Petroules.LIEL.Native;
    using Petroules.LIEL.Properties;
    using Petroules.LIEL.Xml;

    /// <summary>
    /// Represents a component allowing the user to easily set updater properties.
    /// </summary>
    public partial class ApplicationUpdaterComponent : Component
    {
        /// <summary>
        /// An instance of a control to invoke events on the main UI thread.
        /// </summary>
        private Control invokerControl = new Control();

        /// <summary>
        /// The delay before the first check for new updates, in seconds.
        /// </summary>
        private int initialPollDelay = UpdatePolling.DefaultInitialPollDelay;

        /// <summary>
        /// The delay between checks for updates, in seconds.
        /// </summary>
        private int pollInterval = UpdatePolling.DefaultPollDelay;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplicationUpdaterComponent"/> class.
        /// </summary>
        /// <exception cref="UnsupportedPlatformException">The current platform is not supported.</exception>
        public ApplicationUpdaterComponent()
        {
            PlatformUtilities.ThrowIfUnsupported(PlatformID.Win32NT);

            this.InternalInitialize();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplicationUpdaterComponent"/> class.
        /// </summary>
        /// <param name="container">The component's container.</param>
        /// <exception cref="UnsupportedPlatformException">The current platform is not supported.</exception>
        public ApplicationUpdaterComponent(IContainer container)
        {
            PlatformUtilities.ThrowIfUnsupported(PlatformID.Win32NT);

            container.Add(this);
            this.InternalInitialize();
        }

        /// <summary>
        /// Raised when the poller begins checking for an update.
        /// </summary>
        public event EventHandler CheckingForUpdate = delegate { };

        /// <summary>
        /// Raised when an update has been found.
        /// </summary>
        public event EventHandler<UpdateEventArgs> UpdateAvailable = delegate { };

        /// <summary>
        /// Raised when the download process starts.
        /// </summary>
        public event EventHandler<DownloadEventArgs> DownloadingStarted = delegate { };

        /// <summary>
        /// Raised when the download progress has changed.
        /// </summary>
        public event EventHandler<OverallDownloadEventArgs> DownloadingProgressChanged = delegate { };

        /// <summary>
        /// Raised when the download process has completed.
        /// </summary>
        public event EventHandler<DownloadEventArgs> DownloadingCompleted = delegate { };

        /// <summary>
        /// Raised when the update has been downloaded and is ready to install.
        /// </summary>
        public event EventHandler<InstallationEventArgs> ReadyToInstall = delegate { };

        /// <summary>
        /// Raised when there is a status update in the update process.
        /// </summary>
        public event EventHandler<StatusUpdateEventArgs> StatusUpdate = delegate { };

        /// <summary>
        /// Raised when a failure occurs in the update process.
        /// </summary>
        public event EventHandler<UpdateFailureEventArgs> UpdateFailure = delegate { };

        /// <summary>
        /// Gets or sets the delay before the first check for new updates, in seconds.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">Value is less than zero.</exception>
        [DefaultValue(UpdatePolling.DefaultInitialPollDelay)]
        [Description("The delay before the first check for new updates, in seconds.")]
        public int InitialPollDelay
        {
            get
            {
                return this.initialPollDelay;
            }

            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", string.Format(CultureInfo.InvariantCulture, Resources.InitialPollDelayMustBeBetween, int.MaxValue));
                }

                this.initialPollDelay = value;
            }
        }

        /// <summary>
        /// Gets or sets the delay between checks for updates, in seconds.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">Value is less than zero.</exception>
        [DefaultValue(UpdatePolling.DefaultPollDelay)]
        [Description("The delay between checks for updates, in seconds.")]
        public int PollInterval
        {
            get
            {
                return this.pollInterval;
            }

            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", "Poll interval must be between 0 and Int32.MaxValue seconds, inclusive.");
                }

                this.pollInterval = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether to automatically start downloading an update when one is detected.
        /// </summary>
        [DefaultValue(UpdatePolling.DefaultAutoDownload)]
        [Description("Whether to automatically start downloading an update when one is detected.")]
        public bool AutoDownload
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the URL of the product information XML file to get update information from.
        /// </summary>
        [Description("The URL of the product information XML file to get update information from.")]
        [Category("Configuration")]
        public Uri UpdateUrl
        {
            get;
            set;
        }
        
        /// <summary>
        /// Gets the object that handles update downloading.
        /// </summary>
        [Browsable(false)]
        public UpdateDownloader Downloader
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets the object that handles update checking.
        /// </summary>
        [Browsable(false)]
        public UpdatePolling Polling
        {
            get;
            private set;
        }

        /// <summary>
        /// Starts installation of the new version of the application and exits the currently running application.
        /// </summary>
        /// <param name="installFileName">The file name of the main installer file.</param>
        public static void StartInstallation(string installFileName)
        {
            Process.Start(installFileName, "/qb!");
            Application.Exit();
        }

        /// <summary>
        /// Resets the application updater component to its initial state.
        /// </summary>
        public void Reset()
        {
            this.Downloader = new UpdateDownloader(this);
            this.Downloader.DownloadingStarted += this.DownloadingStartedHandler;
            this.Downloader.DownloadingProgressChanged += this.DownloadingProgressChangedHandler;
            this.Downloader.DownloadingCompleted += this.DownloadingCompletedHandler;
            this.Downloader.ReadyToInstall += this.ReadyToInstallHandler;
            this.Downloader.StatusUpdate += this.StatusUpdateHandler;
            this.Downloader.ProcessFailed += this.ProcessFailedHandler;

            this.Polling = new UpdatePolling(this);
            this.Polling.CheckingForUpdate += this.CheckingForUpdateHandler;
            this.Polling.UpdateFound += this.UpdateFoundHandler;
            this.Polling.StatusUpdate += this.StatusUpdateHandler;
            this.Polling.ProcessFailed += this.ProcessFailedHandler;
        }

        /// <summary>
        /// Checks if a new version of the application is available. This method executes synchronously.
        /// </summary>
        /// <returns>See summary.</returns>
        /// <exception cref="UpdateCheckException">The check for updates failed.</exception>
        public bool IsNewVersionAvailable()
        {
            Version newVersion;
            return this.IsNewVersionAvailable(out newVersion);
        }

        /// <summary>
        /// Checks if a new version of the application is available. This method executes synchronously.
        /// </summary>
        /// <param name="newVersion">The new version of the application that is available.</param>
        /// <returns>See summary.</returns>
        /// <exception cref="UpdateCheckException">The check for updates failed.</exception>
        public bool IsNewVersionAvailable(out Version newVersion)
        {
            bool isRequired;
            return this.IsNewVersionAvailable(out newVersion, out isRequired);
        }

        /// <summary>
        /// Checks if a new version of the application is available. This method executes synchronously.
        /// </summary>
        /// <param name="newVersion">The new version of the application that is available.</param>
        /// <param name="isRequired">Whether this update is required.</param>
        /// <returns>See summary.</returns>
        /// <exception cref="UpdateCheckException">The check for updates failed.</exception>
        public bool IsNewVersionAvailable(out Version newVersion, out bool isRequired)
        {
            try
            {
                // Obviously if there is no update URL, we can't do anything
                if (this.UpdateUrl == null)
                {
                    throw new UpdateCheckException(Resources.NoUpdateUrlSpecified, new InvalidOperationException(Resources.UpdateUrlNull));
                }

                // Load the update definition and get the installed version of the application
                UpdateDefinition definition = XmlSerializationHelper.DeserializeUri<UpdateDefinition>(this.UpdateUrl);
                Version installedVersion = new Version(Application.ProductVersion);

                // If the minimum version specified by the server is greater than
                // the installed version, the user is required to install this update
                isRequired = definition.Product.MinimumVersion > installedVersion;

                // If the server's specified version is greater than the one installed, an update is available
                return (newVersion = definition.Product.Version) > installedVersion;
            }
            catch (Exception ex)
            {
                throw new UpdateCheckException(Resources.UpdateCheckFailedShort, ex);
            }
        }

        /// <summary>
        /// Uses the application updater control's hidden object to invoke methods on the UI thread.
        /// </summary>
        /// <param name="method">The method delegate to invoke.</param>
        /// <param name="args">The parameters to pass.</param>
        internal static void RaiseEvent(Delegate method, params object[] args)
        {
            if (method != null)
            {
                try
                {
                    if (((Control)method.Target).InvokeRequired)
                    {
                        ((Control)method.Target).Invoke(method, args);
                        return;
                    }
                }
                catch
                {
                }

                method.DynamicInvoke(args);
            }
        }

        /// <summary>
        /// Performs internal one-time initializations.
        /// </summary>
        private void InternalInitialize()
        {
            this.InitializeComponent();
            this.invokerControl.CreateControl();
            Application.ApplicationExit += this.OnApplicationExit;

            this.InitialPollDelay = UpdatePolling.DefaultInitialPollDelay;
            this.PollInterval = UpdatePolling.DefaultPollDelay;
            this.AutoDownload = UpdatePolling.DefaultAutoDownload;

            this.Reset();
        }

        /// <summary>
        /// Stops the poller and downloader when the application exits.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void OnApplicationExit(object sender, EventArgs e)
        {
            this.Polling.Stop();
            this.Downloader.Stop();
        }

        /// <summary>
        /// DownloadingStarted event handler.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void DownloadingStartedHandler(object sender, DownloadEventArgs e)
        {
            ApplicationUpdaterComponent.RaiseEvent(this.DownloadingStarted, sender, e);
        }

        /// <summary>
        /// DownloadingProgressChanged event handler.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void DownloadingProgressChangedHandler(object sender, OverallDownloadEventArgs e)
        {
            ApplicationUpdaterComponent.RaiseEvent(this.DownloadingProgressChanged, sender, e.FileEventArgs, e.OverallEventArgs);
        }

        /// <summary>
        /// DownloadingCompleted event handler.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void DownloadingCompletedHandler(object sender, DownloadEventArgs e)
        {
            ApplicationUpdaterComponent.RaiseEvent(this.DownloadingCompleted, sender, e);
        }

        /// <summary>
        /// ReadyToInstall event handler.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void ReadyToInstallHandler(object sender, InstallationEventArgs e)
        {
            ApplicationUpdaterComponent.RaiseEvent(this.ReadyToInstall, sender, e);
        }

        /// <summary>
        /// CheckingForUpdate event handler.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void CheckingForUpdateHandler(object sender, EventArgs e)
        {
            ApplicationUpdaterComponent.RaiseEvent(this.CheckingForUpdate, sender, e);
        }

        /// <summary>
        /// UpdateFound event handler.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void UpdateFoundHandler(object sender, UpdateEventArgs e)
        {
            ApplicationUpdaterComponent.RaiseEvent(this.UpdateAvailable, sender, e);
        }

        /// <summary>
        /// StatusUpdate event handler.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void StatusUpdateHandler(object sender, StatusUpdateEventArgs e)
        {
            ApplicationUpdaterComponent.RaiseEvent(this.StatusUpdate, sender, e);
        }

        /// <summary>
        /// ProcessFailed event handler.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void ProcessFailedHandler(object sender, UpdateFailureEventArgs e)
        {
            ApplicationUpdaterComponent.RaiseEvent(this.UpdateFailure, sender, e);
        }
    }
}
