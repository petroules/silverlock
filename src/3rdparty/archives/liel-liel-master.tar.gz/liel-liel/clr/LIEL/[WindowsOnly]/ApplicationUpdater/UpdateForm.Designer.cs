﻿namespace Petroules.LIEL.ApplicationUpdater
{
    partial class UpdateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelCurrentStatus = new System.Windows.Forms.Label();
            this.progressBarProgress = new System.Windows.Forms.ProgressBar();
            this.buttonOK = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.richTextBoxUpdateLog = new System.Windows.Forms.RichTextBox();
            this.buttonRunInBackground = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelCurrentStatus
            // 
            this.labelCurrentStatus.Location = new System.Drawing.Point(12, 9);
            this.labelCurrentStatus.Name = "labelCurrentStatus";
            this.labelCurrentStatus.Size = new System.Drawing.Size(370, 13);
            this.labelCurrentStatus.TabIndex = 0;
            this.labelCurrentStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // progressBarProgress
            // 
            this.progressBarProgress.Location = new System.Drawing.Point(12, 25);
            this.progressBarProgress.Name = "progressBarProgress";
            this.progressBarProgress.Size = new System.Drawing.Size(370, 23);
            this.progressBarProgress.TabIndex = 1;
            // 
            // buttonOK
            // 
            this.buttonOK.Location = new System.Drawing.Point(57, 140);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(75, 23);
            this.buttonOK.TabIndex = 2;
            this.buttonOK.Text = "OK";
            this.buttonOK.UseVisualStyleBackColor = true;
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(138, 140);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 3;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            // 
            // richTextBoxUpdateLog
            // 
            this.richTextBoxUpdateLog.Location = new System.Drawing.Point(12, 54);
            this.richTextBoxUpdateLog.Name = "richTextBoxUpdateLog";
            this.richTextBoxUpdateLog.ReadOnly = true;
            this.richTextBoxUpdateLog.Size = new System.Drawing.Size(370, 80);
            this.richTextBoxUpdateLog.TabIndex = 4;
            this.richTextBoxUpdateLog.Text = "";
            // 
            // buttonRunInBackground
            // 
            this.buttonRunInBackground.Location = new System.Drawing.Point(219, 140);
            this.buttonRunInBackground.Name = "buttonRunInBackground";
            this.buttonRunInBackground.Size = new System.Drawing.Size(119, 23);
            this.buttonRunInBackground.TabIndex = 5;
            this.buttonRunInBackground.Text = "Run in Background";
            this.buttonRunInBackground.UseVisualStyleBackColor = true;
            // 
            // UpdateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(394, 172);
            this.ControlBox = false;
            this.Controls.Add(this.buttonRunInBackground);
            this.Controls.Add(this.richTextBoxUpdateLog);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.progressBarProgress);
            this.Controls.Add(this.labelCurrentStatus);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "UpdateForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Check for Updates";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UpdateForm_FormClosing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelCurrentStatus;
        private System.Windows.Forms.ProgressBar progressBarProgress;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.RichTextBox richTextBoxUpdateLog;
        private System.Windows.Forms.Button buttonRunInBackground;
    }
}