﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using System;

    /// <summary>
    /// Provides data for the <see cref="ApplicationUpdaterComponent.UpdateAvailable"/> event.
    /// </summary>
    public class UpdateEventArgs : EventArgs
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateEventArgs"/> class.
        /// </summary>
        /// <param name="newVersion">The new version of the application that is available.</param>
        public UpdateEventArgs(Version newVersion)
        {
            this.NewVersion = newVersion;
        }

        /// <summary>
        /// Gets the new version of the application that is available.
        /// </summary>
        public Version NewVersion
        {
            get;
            private set;
        }
    }
}
