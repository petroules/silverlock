﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using System;
    using System.ComponentModel;
    using System.Globalization;
    using System.Threading;
    using System.Windows.Forms;
    using Petroules.LIEL.Native;
    using Petroules.LIEL.Properties;
    using Petroules.LIEL.Windows.Forms;

    /// <summary>
    /// Represents a normal <see cref="Form"/> extended to provide simple automatic update functionality.
    /// </summary>
    public partial class AutomaticUpdateFormBase : Form
    {
        /// <summary>
        /// The update form used to show status and progress of an update.
        /// </summary>
        private UpdateForm updateForm;

        /// <summary>
        /// The thread that the application updater runs on.
        /// </summary>
        private Thread thread;

        /// <summary>
        /// Initializes a new instance of the <see cref="AutomaticUpdateFormBase"/> class.
        /// </summary>
        /// <exception cref="UnsupportedPlatformException">The current platform is not supported.</exception>
        public AutomaticUpdateFormBase()
        {
            PlatformUtilities.ThrowIfUnsupported(PlatformID.Win32NT);

            this.InitializeComponent();

            // Hook the updater's events
            this.updater.DownloadingProgressChanged += this.Updater_DownloadingProgressChanged;
            this.updater.ReadyToInstall += this.Updater_ReadyToInstall;
            this.updater.StatusUpdate += this.Updater_StatusUpdate;
        }

        /// <summary>
        /// Gets or sets the URL of the product information XML file to get update information from.
        /// </summary>
        [Category("Misc")]
        [Description("The URL of the product information XML file to get update information from.")]
        public Uri UpdateUrl
        {
            get { return this.updater.UpdateUrl; }
            set { this.updater.UpdateUrl = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the user can choose to cancel an update.
        /// </summary>
        private bool CancellationAllowed
        {
            get;
            set;
        }

        /// <summary>
        /// Starts the updater on checking for updates, or, if it is already running, shows the update form.
        /// </summary>
        public void StartUpdateCheck()
        {
            this.StartUpdateCheck(true);
        }

        /// <summary>
        /// Starts the updater on checking for updates, or, if it is already running, shows the update form.
        /// </summary>
        /// <param name="popupUpdaterForm">Whether to immediately popup the updater form. The default is true.</param>
        public void StartUpdateCheck(bool popupUpdaterForm)
        {
            // Recreate the form and hook events, if necessary
            if (this.updateForm == null)
            {
                this.updateForm = new UpdateForm();
                this.HookUpdateFormEvents();
            }

            // Create the thread if necessary
            if (this.thread == null)
            {
                this.thread = new Thread(this.CheckForUpdates);
                this.thread.Start();

                this.updateForm.SetCheckingForUpdates();
            }

            // Last but not least, show the updater dialog!
            if (popupUpdaterForm && !this.updateForm.GetVisible())
            {
                this.updateForm.ShowDialogSafe();
            }
        }

        /// <summary>
        /// Updates the update form's progress bar.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void Updater_DownloadingProgressChanged(object sender, OverallDownloadEventArgs e)
        {
            this.updateForm.SetDownloading(e.FileEventArgs.Progress);
        }

        /// <summary>
        /// Shows the update form and updates the button's click action when the update is ready to install.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void Updater_ReadyToInstall(object sender, InstallationEventArgs e)
        {
            // Update the GUI to show that the update is ready to install, and hook the appropriate events
            this.updateForm.SetReadyToInstall();
            this.updateForm.OkButtonClicked -= this.UpdateForm_OkButtonClicked_UpdateAvailable;
            this.updateForm.OkButtonClicked += delegate { this.UpdateForm_OkButtonClicked_UpdateDownloaded(sender, e); };

            // Pops up the update form to allow the user to continue or cancel the update
            if (!this.updateForm.GetVisible())
            {
                this.updateForm.ShowDialogSafe();
            }
        }

        /// <summary>
        /// Updates the update form with status messages.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void Updater_StatusUpdate(object sender, StatusUpdateEventArgs e)
        {
            this.updateForm.UpdateLogText += e.Message + System.Environment.NewLine;
        }

        /// <summary>
        /// Proceeds to the next stage of the update process by starting the downloader.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void UpdateForm_OkButtonClicked_UpdateAvailable(object sender, EventArgs e)
        {
            this.updateForm.SetDownloading(0);
            this.updater.Downloader.Start();
        }

        /// <summary>
        /// Proceeds to the next stage of the update process by starting the installation process.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void UpdateForm_OkButtonClicked_UpdateDownloaded(object sender, EventArgs e)
        {
            InstallationEventArgs install = e as InstallationEventArgs;
            if (install != null)
            {
                ApplicationUpdaterComponent.StartInstallation(install.FileName);
            }
            else
            {
                MessageBoxExt.ShowError(Resources.UnableToCastEventArguments);
            }
        }

        /// <summary>
        /// Stops the update process; whatever stage it may be in.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void UpdateForm_CancelButtonClicked(object sender, EventArgs e)
        {
            // Kills the update thread, stopping the process entirely
            if (this.thread != null)
            {
                this.thread.Abort();
                this.thread = null;
            }

            // Close, destroy and nullify!
            this.updateForm.Close();
            this.updateForm.Dispose();
            this.updateForm = null;
        }

        /// <summary>
        /// Hides the update form so the user can continue working while updates are being downloaded.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void UpdateForm_RunInBackgroundButtonClicked(object sender, EventArgs e)
        {
            if (this.updateForm.GetVisible())
            {
                this.updateForm.HideSafe();
            }
        }

        /// <summary>
        /// Hooks events for the update form.
        /// </summary>
        private void HookUpdateFormEvents()
        {
            // Allow the user to cancel the installation of an update?
            this.updateForm.CancellationAllowed = this.CancellationAllowed;

            // Hook the update form's button events so they perform the appropriate
            // actions for each stage of the update process
            this.updateForm.CancelButtonClicked += this.UpdateForm_CancelButtonClicked;
            this.updateForm.RunInBackgroundButtonClicked += this.UpdateForm_RunInBackgroundButtonClicked;
        }

        /// <summary>
        /// Performs the actual work of checking for updates on the background thread.
        /// </summary>
        private void CheckForUpdates()
        {
            try
            {
                this.updateForm.UpdateLogText += Resources.CheckingForUpdates + Environment.NewLine;

                Version newVersion = null;
                bool isRequired = false;
                if (this.updater.IsNewVersionAvailable(out newVersion, out isRequired))
                {
                    this.updateForm.SetUpdateAvailable(newVersion, new Version(Application.ProductVersion));
                    this.updateForm.OkButtonClicked += this.UpdateForm_OkButtonClicked_UpdateAvailable;

                    this.updateForm.UpdateLogText += string.Format(CultureInfo.InvariantCulture, Resources.UpdateAvailable, newVersion, new Version(Application.ProductVersion)) + Environment.NewLine;

                    // We only allow cancellation if the update is not required
                    this.updateForm.CancellationAllowed = !isRequired;

                    // Show the form if it's not visible
                    if (!this.updateForm.GetVisible())
                    {
                        this.updateForm.ShowDialogSafe();
                    }
                }
                else
                {
                    this.updateForm.SetNoUpdateAvailable();

                    this.updateForm.UpdateLogText += Resources.NoUpdateAvailable + Environment.NewLine;

                    // If the form wasn't visible when THIS check was performed,
                    // actually cancel the update process so that the program
                    // actually checks for an update the next time the update
                    // process is invoked rather than being left on this screen
                    if (!this.updateForm.GetVisible())
                    {
                        this.updateForm.ClickCancel();
                    }
                }
            }
            catch (UpdateCheckException ex)
            {
                // We only need to update the log text if the exception was NOT a thread abort, which indicates manual cancellation
                if (!(ex.InnerException is ThreadAbortException))
                {
                    this.updateForm.UpdateLogText += ex.ToString() + Environment.NewLine;
                }
            }
        }
    }
}
