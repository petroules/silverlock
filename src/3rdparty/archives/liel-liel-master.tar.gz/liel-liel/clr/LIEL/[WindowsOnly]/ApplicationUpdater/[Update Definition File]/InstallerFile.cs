﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using System.Xml;
    using System.Xml.Serialization;

    /// <summary>
    /// Defines an installer file; part of an update definition.
    /// </summary>
    public sealed class InstallerFile
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InstallerFile"/> class.
        /// </summary>
        public InstallerFile()
        {
        }

        /// <summary>
        /// Gets or sets the checksum (MD5) of the file.
        /// </summary>
        [XmlAttribute]
        public string Checksum
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the name of the file.
        /// </summary>
        [XmlText]
        public string FileName
        {
            get;
            set;
        }
    }
}
