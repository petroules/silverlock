﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using System;

    /// <summary>
    /// Provides data for the <see cref="ApplicationUpdaterComponent.StatusUpdate"/> event.
    /// </summary>
    public sealed class StatusUpdateEventArgs : EventArgs
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StatusUpdateEventArgs"/> class.
        /// </summary>
        /// <param name="message">The status update message.</param>
        public StatusUpdateEventArgs(string message)
        {
            this.Message = message;
        }

        /// <summary>
        /// Gets the status update message.
        /// </summary>
        public string Message
        {
            get;
            private set;
        }
    }
}
