﻿namespace Petroules.LIEL.ApplicationUpdater
{
    /// <summary>
    /// Enumerates various stages of a download.
    /// </summary>
    public enum DownloadState
    {
        /// <summary>
        /// Indicates that the download has not started.
        /// </summary>
        NotStarted,

        /// <summary>
        /// Indicates that the download is in progress.
        /// </summary>
        InProgress,

        /// <summary>
        /// Indicates that the download has completed.
        /// </summary>
        Completed
    }
}
