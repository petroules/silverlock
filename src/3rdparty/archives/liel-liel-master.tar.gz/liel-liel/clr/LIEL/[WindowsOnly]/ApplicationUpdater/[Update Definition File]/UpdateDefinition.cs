﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using Petroules.LIEL.Xml;

    /// <summary>
    /// Defines an update definition file.
    /// </summary>
    [XmlDtdAttribute("-//Petroules Enterprises//DTD Update Definition 1.0//EN", "http://www.petroules.com/public/dtd/update-definition-1.0.dtd")]
    public sealed class UpdateDefinition
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateDefinition"/> class.
        /// </summary>
        public UpdateDefinition()
        {
            this.Product = new Product();
        }

        /// <summary>
        /// Gets or sets the product the update definition encapsulates.
        /// </summary>
        public Product Product
        {
            get;
            set;
        }
    }
}
