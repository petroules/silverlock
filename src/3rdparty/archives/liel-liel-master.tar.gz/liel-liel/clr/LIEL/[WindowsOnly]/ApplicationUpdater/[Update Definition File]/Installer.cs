﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using System.Collections.ObjectModel;
    using System.Globalization;
    using System.Xml;
    using System.Xml.Serialization;

    /// <summary>
    /// Defines a culture-specific installer; part of an update definition.
    /// </summary>
    public sealed class Installer
    {
        /// <summary>
        /// The list of additional files needed for installation.
        /// </summary>
        private Collection<InstallerFile> additionalFiles;

        /// <summary>
        /// Initializes a new instance of the <see cref="Installer"/> class.
        /// </summary>
        public Installer()
        {
            this.additionalFiles = new Collection<InstallerFile>();
        }

        /// <summary>
        /// Gets or sets the culture of the installer.
        /// </summary>
        [XmlIgnore]
        public CultureInfo Culture
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the culture of the installer, as a string.
        /// </summary>
        [XmlAttribute("Culture")]
        public string CultureString
        {
            get { return this.Culture.ToString(); }
            set { this.Culture = new CultureInfo(value); }
        }

        /// <summary>
        /// Gets or sets the URL prefix of the main file and additional files in the installer (absolute URLs can still be specified).
        /// </summary>
        [XmlAttribute]
        public string Prefix
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the name of the main installer file (usually setup.exe).
        /// </summary>
        [XmlAttribute]
        public string MainFile
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the checksum (MD5) of the main installer file.
        /// </summary>
        [XmlAttribute]
        public string MainFileChecksum
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the list of additional files needed for installation.
        /// </summary>
        public Collection<InstallerFile> AdditionalFiles
        {
            get { return this.additionalFiles; }
        }
    }
}
