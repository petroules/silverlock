﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using System;
    using System.Collections.ObjectModel;
    using System.Xml.Serialization;

    /// <summary>
    /// Defines a product; part of an update definition.
    /// </summary>
    public sealed class Product
    {
        /// <summary>
        /// The culture-specific installers available for this product.
        /// </summary>
        private Collection<Installer> installers;

        /// <summary>
        /// Initializes a new instance of the <see cref="Product"/> class.
        /// </summary>
        public Product()
        {
            this.installers = new Collection<Installer>();
        }

        /// <summary>
        /// Gets or sets the name of the product.
        /// </summary>
        public string Name
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the UNIX name of the product.
        /// </summary>
        public string UnixName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the version number of the latest version of the product available.
        /// </summary>
        [XmlIgnore]
        public Version Version
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the version number of the latest version of the product available, as a string.
        /// </summary>
        [XmlElement("Version")]
        public string VersionString
        {
            get { return this.Version.ToString(); }
            set { this.Version = new Version(value); }
        }

        /// <summary>
        /// Gets or sets the version number of the minimum version of the product that must be installed.
        /// </summary>
        [XmlIgnore]
        public Version MinimumVersion
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the version number of the minimum version of the product that must be installed, as a string.
        /// </summary>
        [XmlElement("MinimumVersion")]
        public string MinimumVersionString
        {
            get { return this.MinimumVersion.ToString(); }
            set { this.MinimumVersion = new Version(value); }
        }

        /// <summary>
        /// Gets the culture-specific installers available for this product.
        /// </summary>
        public Collection<Installer> Installers
        {
            get { return this.installers; }
        }
    }
}
