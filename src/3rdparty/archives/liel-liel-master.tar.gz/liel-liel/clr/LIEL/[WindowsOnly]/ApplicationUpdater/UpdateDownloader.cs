﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using System;
    using System.ComponentModel;
    using System.Globalization;
    using System.IO;
    using System.Net;
    using System.Threading;
    using Petroules.LIEL.IO;
    using Petroules.LIEL.Networking;
    using Petroules.LIEL.Properties;
    using Petroules.LIEL.Xml;

    /// <summary>
    /// Represents a component that downloads updates from a server.
    /// </summary>
    public sealed class UpdateDownloader
    {
        /// <summary>
        /// The number of bytes currently downloaded.
        /// </summary>
        private long currentBytes = 0;

        /// <summary>
        /// The total number of bytes left to download.
        /// </summary>
        private long totalBytes = 0;

        /// <summary>
        /// The thread that does the main downloading work.
        /// </summary>
        private Thread updateThread;

        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateDownloader"/> class.
        /// </summary>
        /// <param name="appUpdater">The application updater component instance.</param>
        public UpdateDownloader(ApplicationUpdaterComponent appUpdater)
        {
            this.ApplicationUpdaterComponent = appUpdater;
        }

        /// <summary>
        /// Raised when the download process starts.
        /// </summary>
        public event EventHandler<DownloadEventArgs> DownloadingStarted = delegate { };

        /// <summary>
        /// Raised when the download progress has changed.
        /// </summary>
        public event EventHandler<OverallDownloadEventArgs> DownloadingProgressChanged = delegate { };

        /// <summary>
        /// Raised when the download process has completed.
        /// </summary>
        public event EventHandler<DownloadEventArgs> DownloadingCompleted = delegate { };

        /// <summary>
        /// Raised when the update has been downloaded and is ready to install.
        /// </summary>
        public event EventHandler<InstallationEventArgs> ReadyToInstall = delegate { };

        /// <summary>
        /// Raised when there is a status update in the update process.
        /// </summary>
        public event EventHandler<StatusUpdateEventArgs> StatusUpdate = delegate { };

        /// <summary>
        /// Raised when a failure occurs in the update process.
        /// </summary>
        public event EventHandler<UpdateFailureEventArgs> ProcessFailed = delegate { };

        /// <summary>
        /// Gets the application updater component instance.
        /// </summary>
        [Browsable(false)]
        public ApplicationUpdaterComponent ApplicationUpdaterComponent
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets the overall progress of the current download.
        /// </summary>
        public int Progress
        {
            get { return Convert.ToInt32(((float)this.currentBytes / (float)this.totalBytes) * 100); }
        }

        /// <summary>
        /// Starts the downloader on downloading the updates.
        /// </summary>
        public void Start()
        {
            if (this.updateThread == null || !this.updateThread.IsAlive)
            {
                this.updateThread = new Thread(new ThreadStart(this.RunThread));
                this.updateThread.Name = "Application Updater Downloader";
                this.updateThread.Start();
            }
        }

        /// <summary>
        /// Kills the downloader thread and stops any download in progress.
        /// </summary>
        public void Stop()
        {
            if (this.updateThread != null)
            {
                this.updateThread.Abort();
                this.updateThread = null;
            }
        }

        /// <summary>
        /// Calculates the total download size for a particular installer.
        /// </summary>
        /// <param name="installer">The installer to calculate the download size for.</param>
        /// <returns>The total size of the download, in bytes.</returns>
        private static long CalculateDownloadSize(Installer installer)
        {
            long runningTotal = NetworkUtilities.GetContentSize(new Uri(Path.Combine(installer.Prefix, installer.MainFile)));

            for (int i = 0; i < installer.AdditionalFiles.Count; i++)
            {
                runningTotal += NetworkUtilities.GetContentSize(new Uri(Path.Combine(installer.Prefix, installer.AdditionalFiles[i].FileName)));
            }

            return runningTotal;
        }

        /// <summary>
        /// Does the main downloading work.
        /// </summary>
        private void RunThread()
        {
            const ChecksumAlgorithm Algorithm = ChecksumAlgorithm.MD5;
            CultureInfo currentCulture = Thread.CurrentThread.CurrentCulture;

            try
            {
                // Get the update file
                UpdateDefinition updateFile = XmlSerializationHelper.DeserializeUri<UpdateDefinition>(this.ApplicationUpdaterComponent.UpdateUrl);
                Installer installer = null;

                this.StatusUpdate(this, new StatusUpdateEventArgs(Resources.DownloadedUpdateDefinitionFile));

                // Create a temporary directory to hold our install file(s)
                DirectoryInfo info = Directory.CreateDirectory(Path.Combine(Path.GetTempPath(), Path.GetRandomFileName()));

                this.StatusUpdate(this, new StatusUpdateEventArgs(Resources.CreatedTemporaryDirectory));

                WebClient client = new WebClient();
                client.DownloadProgressChanged += this.Client_DownloadProgressChanged;

                // Find the installer with the matching culture
                for (int i = 0; i < updateFile.Product.Installers.Count; i++)
                {
                    // Check for the correct installer for this current culture
                    if (updateFile.Product.Installers[i].Culture.LCID == currentCulture.LCID)
                    {
                        installer = updateFile.Product.Installers[i];
                        this.currentBytes = 0;
                        this.totalBytes = UpdateDownloader.CalculateDownloadSize(installer);

                        this.DownloadingStarted(this, new DownloadEventArgs(0, 0, this.totalBytes, DownloadState.NotStarted));

                        // Download the main installer file
                        long mainFileSize = 0;
                        if (!this.DownloadFile(client, Path.Combine(info.FullName, installer.MainFile), new Uri(Path.Combine(installer.Prefix, installer.MainFile)), installer.MainFileChecksum, Algorithm, out mainFileSize))
                        {
                            return;
                        }

                        this.currentBytes += mainFileSize;

                        // ...and any additional files
                        for (int j = 0; j < installer.AdditionalFiles.Count; j++)
                        {
                            long fileSize = 0;
                            if (!this.DownloadFile(client, Path.Combine(info.FullName, installer.AdditionalFiles[j].FileName), new Uri(Path.Combine(installer.Prefix, installer.AdditionalFiles[j].FileName)), installer.AdditionalFiles[j].Checksum, Algorithm, out fileSize))
                            {
                                return;
                            }

                            this.currentBytes += fileSize;
                        }

                        this.DownloadingCompleted(this, new DownloadEventArgs(100, this.currentBytes, this.totalBytes, DownloadState.Completed));
                    }
                }

                if (installer != null)
                {
                    this.ReadyToInstall(this, new InstallationEventArgs(Path.Combine(info.FullName, installer.MainFile), updateFile.Product.Version));
                }
                else
                {
                    this.ProcessFailed(this, new UpdateFailureEventArgs(null, string.Format(CultureInfo.InvariantCulture, Resources.NoInstallerFound, currentCulture)));
                }
            }
            catch (WebException ex)
            {
                this.ProcessFailed(this, new UpdateFailureEventArgs(ex));
            }
            catch (ThreadAbortException ex)
            {
                this.ProcessFailed(this, new UpdateFailureEventArgs(ex, Resources.DownloadProcessManuallyAborted));
            }
        }

        /// <summary>
        /// Downloads the specified file that is part of the installation.
        /// </summary>
        /// <param name="client">The <see cref="WebClient"/> used to perform the download.</param>
        /// <param name="localFile">The local file to write to.</param>
        /// <param name="remoteFile">The remote file to read from.</param>
        /// <param name="fileChecksum">The checksum of the file.</param>
        /// <param name="checksumAlgorithm">The algorithm used for the file checksum.</param>
        /// <param name="fileSize">The size of the file in bytes.</param>
        /// <returns>Whether the checksum succeeded.</returns>
        private bool DownloadFile(WebClient client, string localFile, Uri remoteFile, string fileChecksum, ChecksumAlgorithm checksumAlgorithm, out long fileSize)
        {
            this.StatusUpdate(this, new StatusUpdateEventArgs(string.Format(CultureInfo.InvariantCulture, Resources.DownloadingFile, remoteFile)));

            // Download the file
            client.DownloadFileAsync(remoteFile, localFile);

            // Block while the file is downloading, but the event handler will allow progress reporting
            while (client.IsBusy)
            {
                // Sleep for a millisecond so we don't jam up the processor too much
                Thread.Sleep(1);
            }

            // Make sure the file was downloaded intact
            if (!ChecksumUtilities.PerformChecksum(localFile, fileChecksum, checksumAlgorithm))
            {
                this.ProcessFailed(this, new UpdateFailureEventArgs(null, string.Format(CultureInfo.InvariantCulture, Resources.FileChecksumFailed, remoteFile)));
                fileSize = 0;
                return false;
            }

            this.StatusUpdate(this, new StatusUpdateEventArgs(string.Format(CultureInfo.InvariantCulture, Resources.CompletedDownloadingFile, remoteFile)));

            // Measure the file
            fileSize = new FileInfo(localFile).Length;

            return true;
        }

        /// <summary>
        /// Reports download progress.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void Client_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            DownloadEventArgs fileArgs = new DownloadEventArgs(
                    e.ProgressPercentage,
                    e.BytesReceived,
                    e.TotalBytesToReceive,
                    e.BytesReceived == e.TotalBytesToReceive ? DownloadState.Completed : DownloadState.InProgress);

            DownloadEventArgs overallArgs = new DownloadEventArgs(
                    this.Progress,
                    this.currentBytes,
                    this.totalBytes,
                    this.currentBytes == this.totalBytes ? DownloadState.Completed : DownloadState.InProgress);

            this.DownloadingProgressChanged(this, new OverallDownloadEventArgs(fileArgs, overallArgs));
        }
    }
}
