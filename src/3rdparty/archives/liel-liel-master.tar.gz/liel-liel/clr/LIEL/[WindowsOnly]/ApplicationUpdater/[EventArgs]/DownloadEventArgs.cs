﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using System;
    using Petroules.LIEL.Properties;

    /// <summary>
    /// Provides data for the <see cref="ApplicationUpdaterComponent.DownloadingStarted"/> and <see cref="ApplicationUpdaterComponent.DownloadingCompleted"/> events.
    /// </summary>
    public sealed class DownloadEventArgs : EventArgs
    {
        /// <summary>
        /// The percentage of overall download progress, from 0 to 100.
        /// </summary>
        private int progress;

        /// <summary>
        /// Initializes a new instance of the <see cref="DownloadEventArgs"/> class.
        /// </summary>
        /// <param name="progress">The percentage of overall download progress, from 0 to 100.</param>
        /// <param name="downloadedBytes">The number of bytes downloaded so far.</param>
        /// <param name="totalBytes">The total number of bytes to download.</param>
        /// <param name="state">The current state of the download.</param>
        /// <exception cref="ArgumentOutOfRangeException">Parameter progress was less than zero or greater than 100.</exception>
        public DownloadEventArgs(int progress, long downloadedBytes, long totalBytes, DownloadState state)
        {
            this.Progress = progress;
        }

        /// <summary>
        /// Gets the percentage of overall download progress, from 0 to 100.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">Progress is less than zero or greater than 100.</exception>
        public int Progress
        {
            get
            {
                return this.progress;
            }

            private set
            {
                if (value < 0 || value > 100)
                {
                    throw new ArgumentOutOfRangeException("value", Resources.ProgressMustBeInRange);
                }

                this.progress = value;
            }
        }

        /// <summary>
        /// Gets the number of bytes downloaded so far.
        /// </summary>
        public long DownloadedBytes
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets the total number of bytes to download.
        /// </summary>
        public long TotalBytes
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets the current state of the download.
        /// </summary>
        public DownloadState State
        {
            get;
            private set;
        }
    }
}
