﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using System;

    /// <summary>
    /// Provides data for the <see cref="ApplicationUpdaterComponent.UpdateFailure"/> event.
    /// </summary>
    public sealed class UpdateFailureEventArgs : EventArgs
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateFailureEventArgs"/> class.
        /// </summary>
        /// <param name="ex">The exception that caused the update process to fail.</param>
        public UpdateFailureEventArgs(Exception ex)
        {
            this.Exception = ex;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateFailureEventArgs"/> class.
        /// </summary>
        /// <param name="ex">The exception that caused the update process to fail.</param>
        /// <param name="message">The error message related to the failure in the update process.</param>
        public UpdateFailureEventArgs(Exception ex, string message)
            : this(ex)
        {
            this.Message = message;
        }

        /// <summary>
        /// Gets the exception that caused the update process to fail.
        /// </summary>
        public Exception Exception
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets the error message related to the failure in the update process.
        /// </summary>
        public string Message
        {
            get;
            private set;
        }
    }
}
