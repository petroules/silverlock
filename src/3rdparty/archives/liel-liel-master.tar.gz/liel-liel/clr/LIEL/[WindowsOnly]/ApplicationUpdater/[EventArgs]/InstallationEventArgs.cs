﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using System;

    /// <summary>
    /// Provides data for the <see cref="ApplicationUpdaterComponent.ReadyToInstall"/> event.
    /// </summary>
    public sealed class InstallationEventArgs : UpdateEventArgs
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InstallationEventArgs"/> class.
        /// </summary>
        /// <param name="fileName">The file name of the downloaded main installation file.</param>
        /// <param name="newVersion">The new version of the application that is available.</param>
        public InstallationEventArgs(string fileName, Version newVersion)
            : base(newVersion)
        {
            this.FileName = fileName;
        }

        /// <summary>
        /// Gets the file name of the downloaded main installation file.
        /// </summary>
        public string FileName
        {
            get;
            private set;
        }
    }
}
