﻿namespace Petroules.LIEL.ApplicationUpdater
{
    /// <summary>
    /// Enumerates various stages of the update process.
    /// </summary>
    public enum UpdateStatus
    {
        /// <summary>
        /// Indicates that the updater is currently checking for updates.
        /// </summary>
        CheckingForUpdates,

        /// <summary>
        /// Indicates that an update is available.
        /// </summary>
        UpdateAvailable,

        /// <summary>
        /// Indicates that no update is available.
        /// </summary>
        NoUpdateAvailable,

        /// <summary>
        /// Indicates than an update is currently downloading.
        /// </summary>
        Downloading,

        /// <summary>
        /// Indicates that the update has been downloaded and is ready to install.
        /// </summary>
        ReadyToInstall,

        /// <summary>
        /// Indicates that the update process has failed.
        /// </summary>
        Failed
    }
}
