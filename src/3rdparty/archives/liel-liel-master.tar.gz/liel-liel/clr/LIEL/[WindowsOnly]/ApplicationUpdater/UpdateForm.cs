﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using System;
    using System.Globalization;
    using System.Windows.Forms;
    using Petroules.LIEL.Properties;
    using Petroules.LIEL.Windows.Forms;

    /// <summary>
    /// Represents a generic automatic updater form that the user can interact with.
    /// </summary>
    public partial class UpdateForm : Form
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateForm"/> class.
        /// </summary>
        public UpdateForm()
        {
            this.InitializeComponent();
            this.progressBarProgress.MarqueeAnimationSpeed = 25;
        }

        /// <summary>
        /// Raised when the OK button is clicked.
        /// </summary>
        public event EventHandler OkButtonClicked
        {
            add { this.buttonOK.Click += value; }
            remove { this.buttonOK.Click -= value; }
        }

        /// <summary>
        /// Raised when the cancel button is clicked.
        /// </summary>
        public event EventHandler CancelButtonClicked
        {
            add { this.buttonCancel.Click += value; }
            remove { this.buttonCancel.Click -= value; }
        }

        /// <summary>
        /// Raised when the run in background button is clicked.
        /// </summary>
        public event EventHandler RunInBackgroundButtonClicked
        {
            add { this.buttonRunInBackground.Click += value; }
            remove { this.buttonRunInBackground.Click -= value; }
        }

        /// <summary>
        /// Gets the current status of the update.
        /// </summary>
        public UpdateStatus UpdateStatus
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets or sets a value indicating whether the user can choose to cancel an update.
        /// </summary>
        public bool CancellationAllowed
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the text in the update form's log. This property is thread-safe.
        /// </summary>
        public string UpdateLogText
        {
            get { return this.richTextBoxUpdateLog.GetText(); }
            set { this.richTextBoxUpdateLog.SetText(value); }
        }

        /// <summary>
        /// Gets or sets the progress percentage (0-100) of the download bar. This property is thread-safe.
        /// </summary>
        private int Progress
        {
            get { return this.progressBarProgress.GetValue(); }
            set { this.progressBarProgress.SetValue(value); }
        }

        /// <summary>
        /// Calls the <see cref="IButtonControl.PerformClick"/> method of the cancel button.
        /// </summary>
        public void ClickCancel()
        {
            this.buttonCancel.PerformClick();
        }

        /// <summary>
        /// Sets the update form's status to 'checking for updates'.
        /// </summary>
        public void SetCheckingForUpdates()
        {
            this.buttonOK.SetEnabled(false);
            this.buttonCancel.SetEnabled(this.CancellationAllowed);
            this.buttonRunInBackground.SetEnabled(true);

            this.Progress = 0;
            this.progressBarProgress.SetStyle(ProgressBarStyle.Marquee);
            this.labelCurrentStatus.SetText(Resources.CheckingForUpdates);

            this.UpdateStatus = UpdateStatus.CheckingForUpdates;
        }

        /// <summary>
        /// Sets the update form's status to 'update available'.
        /// </summary>
        /// <param name="newVersion">The new version of the application that is available.</param>
        /// <param name="currentVersion">The currently installed version of the application.</param>
        public void SetUpdateAvailable(Version newVersion, Version currentVersion)
        {
            this.SetUpdateAvailable(true, newVersion, currentVersion);

            this.UpdateStatus = UpdateStatus.UpdateAvailable;
        }

        /// <summary>
        /// Sets the update form's status to 'no update available'.
        /// </summary>
        public void SetNoUpdateAvailable()
        {
            this.SetUpdateAvailable(false, null, null);

            this.UpdateStatus = UpdateStatus.NoUpdateAvailable;
        }

        /// <summary>
        /// Sets the update form's status to 'downloading'.
        /// </summary>
        /// <param name="progress">The progress of the download, from 0 to 100.</param>
        public void SetDownloading(int progress)
        {
            this.buttonOK.SetEnabled(false);
            this.buttonCancel.SetEnabled(this.CancellationAllowed);
            this.buttonRunInBackground.SetEnabled(true);

            this.Progress = progress;
            this.progressBarProgress.SetStyle(ProgressBarStyle.Continuous);
            this.labelCurrentStatus.SetText(string.Format(CultureInfo.CurrentCulture, Resources.DownloadingUpdate, this.Progress));

            this.UpdateStatus = UpdateStatus.Downloading;
        }

        /// <summary>
        /// Sets the update form's status to 'ready to install'.
        /// </summary>
        public void SetReadyToInstall()
        {
            this.buttonOK.SetEnabled(true);
            this.buttonCancel.SetEnabled(this.CancellationAllowed);
            this.buttonRunInBackground.SetEnabled(false);

            this.Progress = 0;
            this.progressBarProgress.SetStyle(ProgressBarStyle.Continuous);
            this.labelCurrentStatus.SetText("Ready to install. Click OK to continue.");

            this.UpdateStatus = UpdateStatus.ReadyToInstall;
        }

        /// <summary>
        /// Sets the update form's status to 'failed'.
        /// </summary>
        public void SetFailed()
        {
            this.buttonOK.SetEnabled(false);
            this.buttonCancel.SetEnabled(true);
            this.buttonRunInBackground.SetEnabled(false);

            this.Progress = 0;
            this.progressBarProgress.SetStyle(ProgressBarStyle.Continuous);
            this.labelCurrentStatus.SetText(Resources.UpdateFailedShort);

            this.UpdateStatus = UpdateStatus.Failed;
        }

        /// <summary>
        /// Sets the update form's status to 'update available' or 'no update available', depending on the parameters passed.
        /// </summary>
        /// <param name="available">True for 'update available', false for 'no update available'.</param>
        /// <param name="newVersion">The new version of the application that is available. Set to null if <paramref name="available"/> is false.</param>
        /// <param name="currentVersion">The currently installed version of the application. Set to null if <paramref name="available"/> is false.</param>
        private void SetUpdateAvailable(bool available, Version newVersion, Version currentVersion)
        {
            this.buttonOK.SetEnabled(available);
            this.buttonCancel.SetEnabled(available ? this.CancellationAllowed : false);
            this.buttonRunInBackground.SetEnabled(available);

            this.Progress = 0;
            this.progressBarProgress.SetStyle(ProgressBarStyle.Continuous);
            this.labelCurrentStatus.SetText(available ? string.Format(CultureInfo.InvariantCulture, Resources.UpdateAvailable, newVersion, currentVersion) : Resources.NoUpdateAvailable);
        }

        /// <summary>
        /// Prevents the update form from being closed by the user.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="e">The event arguments.</param>
        private void UpdateForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
            }
        }
    }
}
