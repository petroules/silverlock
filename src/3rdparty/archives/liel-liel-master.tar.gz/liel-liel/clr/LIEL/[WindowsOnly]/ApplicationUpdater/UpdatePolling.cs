﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using System;
    using System.ComponentModel;
    using System.Globalization;
    using System.Threading;
    using Petroules.LIEL.Properties;

    /// <summary>
    /// Represents a component that continuously polls a server for updates.
    /// </summary>
    public sealed class UpdatePolling
    {
        /// <summary>
        /// The default delay before the first check for new updates, in seconds.
        /// </summary>
        public const int DefaultInitialPollDelay = 15;

        /// <summary>
        /// The default delay between checks for updates, in seconds.
        /// </summary>
        public const int DefaultPollDelay = 30;

        /// <summary>
        /// The default value of whether to automatically start the update poller when the application starts.
        /// </summary>
        public const bool DefaultAutoStart = true;

        /// <summary>
        /// The default value of whether to automatically start downloading an update when one is detected.
        /// </summary>
        public const bool DefaultAutoDownload = true;

        /// <summary>
        /// The thread that does the main polling work.
        /// </summary>
        private Thread pollingThread;

        /// <summary>
        /// Initializes a new instance of the <see cref="UpdatePolling"/> class.
        /// </summary>
        /// <param name="appUpdater">The application updater component instance.</param>
        public UpdatePolling(ApplicationUpdaterComponent appUpdater)
        {
            this.ApplicationUpdaterComponent = appUpdater;
        }

        /// <summary>
        /// Raised when the poller begins checking for an update.
        /// </summary>
        public event EventHandler CheckingForUpdate = delegate { };

        /// <summary>
        /// Raised when an update has been found.
        /// </summary>
        public event EventHandler<UpdateEventArgs> UpdateFound = delegate { };

        /// <summary>
        /// Raised when there is a status update in the update process.
        /// </summary>
        public event EventHandler<StatusUpdateEventArgs> StatusUpdate = delegate { };

        /// <summary>
        /// Raised when a failure occurs in the update process.
        /// </summary>
        public event EventHandler<UpdateFailureEventArgs> ProcessFailed = delegate { };

        /// <summary>
        /// Gets the application updater component instance.
        /// </summary>
        [Browsable(false)]
        public ApplicationUpdaterComponent ApplicationUpdaterComponent
        {
            get;
            private set;
        }

        /// <summary>
        /// Starts the poller on checking for updates.
        /// </summary>
        public void Start()
        {
            // If the poller thread is null or dead, recreate it
            if (this.pollingThread == null || !this.pollingThread.IsAlive)
            {
                this.pollingThread = new Thread(new ThreadStart(this.RunThread));
                this.pollingThread.Name = "Application Updater Poller";
                this.pollingThread.Start();
            }
        }
        
        /// <summary>
        /// Kills the poller thread and stops checking for updates.
        /// </summary>
        public void Stop()
        {
            if (this.pollingThread != null)
            {
                this.pollingThread.Abort();
                this.pollingThread = null;
            }
        }

        /// <summary>
        /// Does the main polling work.
        /// </summary>
        private void RunThread()
        {
            int currentPollRate = this.ApplicationUpdaterComponent.InitialPollDelay;

            try
            {
                while (true)
                {
                    if (currentPollRate > 0)
                    {
                        // Wait before checking for updates again
                        Thread.Sleep(TimeSpan.FromSeconds(currentPollRate));
                    }

                    currentPollRate = this.ApplicationUpdaterComponent.PollInterval;

                    this.CheckingForUpdate(this, EventArgs.Empty);

                    bool updatesAvailable = false;
                    Version updateVersionAvailable = null;
                    try
                    {
                        updatesAvailable = this.ApplicationUpdaterComponent.IsNewVersionAvailable(out updateVersionAvailable);
                    }
                    catch (UpdateCheckException ex)
                    {
                        this.ProcessFailed(this, new UpdateFailureEventArgs(ex, string.Format(CultureInfo.InvariantCulture, Resources.UpdateCheckFailed, ex.Message)));
                        updatesAvailable = false;
                    }

                    // If there were updates available...
                    if (updatesAvailable)
                    {
                        this.UpdateFound(this, new UpdateEventArgs(updateVersionAvailable));

                        // Download and apply the update
                        if (this.ApplicationUpdaterComponent.AutoDownload)
                        {
                            this.ApplicationUpdaterComponent.Downloader.Start();
                            return;
                        }
                    }
                    else
                    {
                        this.ProcessFailed(this, new UpdateFailureEventArgs(null, Resources.NoUpdateAvailable));
                    }
                }
            }
            catch (ThreadAbortException ex)
            {
                this.ProcessFailed(this, new UpdateFailureEventArgs(ex, "The polling process was manually aborted."));
            }
        }
    }
}
