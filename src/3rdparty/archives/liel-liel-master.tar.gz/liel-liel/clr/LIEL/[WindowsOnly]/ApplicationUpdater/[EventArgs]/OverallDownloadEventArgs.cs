﻿namespace Petroules.LIEL.ApplicationUpdater
{
    using System;

    /// <summary>
    /// Provides data for the <see cref="ApplicationUpdaterComponent.DownloadingProgressChanged"/> event.
    /// </summary>
    public sealed class OverallDownloadEventArgs : EventArgs
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OverallDownloadEventArgs"/> class.
        /// </summary>
        /// <param name="file">The event arguments for the current file download progress.</param>
        /// <param name="overall">The event arguments for the overall download progress.</param>
        public OverallDownloadEventArgs(DownloadEventArgs file, DownloadEventArgs overall)
        {
            this.FileEventArgs = file;
            this.OverallEventArgs = overall;
        }

        /// <summary>
        /// Gets the event arguments for the current file download progress.
        /// </summary>
        public DownloadEventArgs FileEventArgs
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets the event arguments for the overall download progress.
        /// </summary>
        public DownloadEventArgs OverallEventArgs
        {
            get;
            private set;
        }
    }
}
