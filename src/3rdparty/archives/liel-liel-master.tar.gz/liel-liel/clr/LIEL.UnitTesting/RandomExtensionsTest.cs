﻿namespace Petroules.LIEL.UnitTesting
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.LIEL;

    [TestClass]
    public class RandomExtensionsTest
    {
        [TestMethod]
        public void GenerateNumberTest()
        {
            Random random = new Random();
            GenerateNumberTestHelper(random, 0, 5);
            GenerateNumberTestHelper(random, 2, 73);
            GenerateNumberTestHelper(random, -5, -1);
            GenerateNumberTestHelper(random, -3, -3);
            GenerateNumberTestHelper(random, 93, 393);
            GenerateNumberTestHelper(random, 13, 29);
            GenerateNumberTestHelper(random, 13, 13);
            GenerateNumberTestHelper(random, 13, 14);
            GenerateNumberTestHelper(random, 13, 15);

            GenerateNumberTestHelper(random, int.MaxValue, int.MaxValue);
            GenerateNumberTestHelper(random, int.MinValue + 1, int.MaxValue);
            GenerateNumberTestHelper(random, int.MinValue, int.MaxValue);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void GenerateNumberTestException()
        {
            GenerateNumberTestHelper(new Random(), -347, -2000);
        }

        [TestMethod]
        public void GenerateEnumTest()
        {
            Random random = new Random();
            Assert.IsInstanceOfType(RandomExtensions.GenerateEnumValue<DayOfWeek>(random), typeof(DayOfWeek));
        }

        private void GenerateNumberTestHelper(Random random, int min, int max)
        {
            int testResult = RandomExtensions.GenerateNumber(random, min, max);
            Assert.IsTrue(testResult >= min && testResult <= max);
        }
    }
}
