﻿namespace Petroules.LIEL.UnitTesting
{
    using System;
    using System.Globalization;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.LIEL.Web;

    [TestClass]
    public class W3CValidatorTest
    {
        [TestMethod]
        public void ReturnsValidMarkupTestPetroulesEnterprises()
        {
            ReturnsValidMarkupTest(new Uri("http://www.petroules.com/"));
        }

        [TestMethod]
        public void ReturnsValidMarkupTestMicrosoft()
        {
            ReturnsValidMarkupTest(new Uri("http://www.microsoft.com/"));
        }

        [TestMethod]
        public void ReturnsValidMarkupTestDirect1()
        {
            ReturnsValidMarkupTest("<html><head><title>Test</title></head><body><div>Test</div></body></html>");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ReturnsValidMarkupTestException1()
        {
            W3CValidator.ReturnsValidMarkup(null, true);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ReturnsValidMarkupTestException2()
        {
            W3CValidator.ReturnsValidMarkup("");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ReturnsValidMarkupTestException3()
        {
            W3CValidator.ReturnsValidMarkup(null as Uri);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ReturnsValidMarkupTestException4()
        {
            W3CValidator.ReturnsValidMarkup(null as string);
        }

        public void ReturnsValidMarkupTest(string markup)
        {
            W3CValidityCheckResult result3 = W3CValidator.ReturnsValidMarkup(markup);
            Console.WriteLine("Direct Markup Input");
            Console.WriteLine(string.Format(CultureInfo.InvariantCulture, "Valid: {0}", result3.IsValid));
            Console.WriteLine(string.Format(CultureInfo.InvariantCulture, "Warnings: {0}", result3.WarningCount));
            Console.WriteLine(string.Format(CultureInfo.InvariantCulture, "Errors: {0}", result3.ErrorCount));

            // We get at least one warning because of the UTF8 assumption on direct input
            Assert.IsTrue(result3.WarningCount > 0);
        }

        public void ReturnsValidMarkupTest(Uri url)
        {
            W3CValidityCheckResult result1 = W3CValidator.ReturnsValidMarkup(url);
            Console.WriteLine("URL, Fetch-by-URL");
            Console.WriteLine(string.Format(CultureInfo.InvariantCulture, "Valid: {0}", result1.IsValid));
            Console.WriteLine(string.Format(CultureInfo.InvariantCulture, "Warnings: {0}", result1.WarningCount));
            Console.WriteLine(string.Format(CultureInfo.InvariantCulture, "Errors: {0}", result1.ErrorCount));

            Console.WriteLine();

            W3CValidityCheckResult result2 = W3CValidator.ReturnsValidMarkup(url, true);
            Console.WriteLine("URL, Direct Input");
            Console.WriteLine(string.Format(CultureInfo.InvariantCulture, "Valid: {0}", result2.IsValid));
            Console.WriteLine(string.Format(CultureInfo.InvariantCulture, "Warnings: {0}", result2.WarningCount));
            Console.WriteLine(string.Format(CultureInfo.InvariantCulture, "Errors: {0}", result2.ErrorCount));

            // We get at least one warning because of the UTF8 assumption on direct input
            Assert.IsTrue(result2.WarningCount > 0);
        }
    }
}
