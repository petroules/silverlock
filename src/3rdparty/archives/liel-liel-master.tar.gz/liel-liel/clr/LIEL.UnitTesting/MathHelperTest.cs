﻿namespace Petroules.LIEL.UnitTesting
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.LIEL.Math;

    [TestClass]
    public class MathHelperTest
    {
        [TestMethod]
        public void ClampTest()
        {
            Assert.AreEqual(100, MathHelper.Clamp(150, 0, 100));
            Assert.AreEqual(100, MathHelper.Clamp(100, 0, 100));
            Assert.AreEqual(0, MathHelper.Clamp(0, 0, 100));
            Assert.AreEqual(50.3f, MathHelper.Clamp(50.3f, 0, 100));
            Assert.AreEqual(50.3, MathHelper.Clamp(50.3, 0, 100));
            Assert.AreEqual(150.1, MathHelper.Clamp(756.1, 0.2, 150.1));
            Assert.AreEqual('c', MathHelper.Clamp('z', 'a', 'c'));
            Assert.AreEqual("hello", MathHelper.Clamp("test", "apple", "hello"));
            Assert.AreEqual("application", MathHelper.Clamp("application", "apple", "hello"));
            Assert.AreEqual(0, MathHelper.Clamp(-10, min: 0));
            Assert.AreEqual(10, MathHelper.Clamp(20, max: 10));
            Assert.AreEqual(1, MathHelper.Clamp(1));
        }

        [TestMethod]
        public void WrapTest()
        {
            Assert.AreEqual(0, MathHelper.Wrap(0, 0, 360));
            Assert.AreEqual(359, MathHelper.Wrap(-1, 0, 360));
            Assert.AreEqual(1, MathHelper.Wrap(361, 0, 360));
            Assert.AreEqual(50, MathHelper.Wrap(50, 0, 360));
            Assert.AreEqual(0, MathHelper.Wrap(720, 0, 360));
            Assert.AreEqual(359, MathHelper.Wrap(719, 0, 360));
            Assert.AreEqual(-180, MathHelper.Wrap(180, -180, 180));
            Assert.AreEqual(-179, MathHelper.Wrap(181, -180, 180));
            Assert.AreEqual(179, MathHelper.Wrap(-181, -180, 180));
        }

        [TestMethod]
        public void IsPowerOfTwoTest()
        {
            Assert.AreEqual(false, MathHelper.IsPowerOfTwo(int.MinValue));
            Assert.AreEqual(false, MathHelper.IsPowerOfTwo(0));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(1));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(2));
            Assert.AreEqual(false, MathHelper.IsPowerOfTwo(3));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(4));
            Assert.AreEqual(false, MathHelper.IsPowerOfTwo(5));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(8));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(16));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(32));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(64));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(128));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(256));
            Assert.AreEqual(false, MathHelper.IsPowerOfTwo(500));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(512));
            Assert.AreEqual(false, MathHelper.IsPowerOfTwo(1000));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(1024));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(2048));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(4096));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(8192));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(16384));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(32768));
            Assert.AreEqual(true, MathHelper.IsPowerOfTwo(65536));
            Assert.AreEqual(false, MathHelper.IsPowerOfTwo(int.MaxValue));
        }

        [TestMethod]
        public void NearestPowerOfTwoTest()
        {
            Assert.AreEqual(1, MathHelper.NearestPowerOfTwo(int.MinValue));
            Assert.AreEqual(1, MathHelper.NearestPowerOfTwo(0));
            Assert.AreEqual(1, MathHelper.NearestPowerOfTwo(1));
            Assert.AreEqual(128, MathHelper.NearestPowerOfTwo(100));
            Assert.AreEqual(256, MathHelper.NearestPowerOfTwo(200));
            Assert.AreEqual(256, MathHelper.NearestPowerOfTwo(255));
            Assert.AreEqual(256, MathHelper.NearestPowerOfTwo(256));
            Assert.AreEqual(512, MathHelper.NearestPowerOfTwo(257));
            Assert.AreEqual(512, MathHelper.NearestPowerOfTwo(300));
            Assert.AreEqual(512, MathHelper.NearestPowerOfTwo(400));
            Assert.AreEqual(512, MathHelper.NearestPowerOfTwo(500));
        }
    }
}
