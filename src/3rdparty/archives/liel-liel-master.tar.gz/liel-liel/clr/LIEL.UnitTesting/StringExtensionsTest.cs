﻿namespace Petroules.LIEL.UnitTesting
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.LIEL;

    [TestClass]
    public class StringExtensionsTest
    {
        [TestMethod]
        public void ContainsAnyOfTest()
        {
            // Testing overload
            Assert.AreEqual(true, StringExtensions.ContainsAnyOf("products & services of our company", "Products and Services", true));
            Assert.AreEqual(false, StringExtensions.ContainsAnyOf("products & services of our company", "Products and Services", false));
            Assert.AreEqual(true, StringExtensions.ContainsAnyOf("products & services of our company", "products and services", false));

            // Testing overload
            Assert.AreEqual(true, StringExtensions.ContainsAnyOf("products & services of our company", "Products and Services"));
            Assert.AreEqual(true, StringExtensions.ContainsAnyOf("products & services of our company", "products and services"));

            // Testing overload
            Assert.AreEqual(true, StringExtensions.ContainsAnyOf("products & services of our company", new string[] { "Products", "and", "Services" }, true));
            Assert.AreEqual(false, StringExtensions.ContainsAnyOf("products & services of our company", new string[] { "Products", "and", "Services" }, false));
            Assert.AreEqual(true, StringExtensions.ContainsAnyOf("products & services of our company", new string[] { "products", "and", "services" }, false));

            // Testing overload
            Assert.AreEqual(true, StringExtensions.ContainsAnyOf("products & services of our company", new string[] { "Products", "and", "Services" }));
            Assert.AreEqual(true, StringExtensions.ContainsAnyOf("products & services of our company", new string[] { "products", "and", "services" }));
        }
    }
}
