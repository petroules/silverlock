﻿namespace Petroules.LIEL.UnitTesting
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.LIEL.IO;

    [TestClass]
    public class SerializationHelperTest
    {
        public void SerializeStringTestHelper<T>()
        {
            T obj = default(T);
            Assert.AreEqual(obj, SerializationHelper.DeserializeString<T>(SerializationHelper.SerializeString<T>(obj)));
        }

        [TestMethod]
        public void SerializeStringTest()
        {
            SerializeStringTestHelper<int>();
            SerializeStringTestHelper<bool>();
        }

        public void SerializeBytesTestHelper<T>()
        {
            T obj = default(T);
            Assert.AreEqual(obj, SerializationHelper.DeserializeBytes<T>(SerializationHelper.SerializeBytes<T>(obj)));
        }

        [TestMethod]
        public void SerializeBytesTest()
        {
            SerializeBytesTestHelper<int>();
            SerializeBytesTestHelper<bool>();
        }
    }
}
