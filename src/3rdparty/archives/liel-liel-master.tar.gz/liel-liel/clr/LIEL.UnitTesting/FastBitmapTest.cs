﻿namespace Petroules.LIEL.UnitTesting
{
    using System.Drawing;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.LIEL.Imaging;
    
    [TestClass]
    public class FastBitmapTest
    {
        [TestMethod]
        public void GetPixelTest()
        {
            Bitmap image = new Bitmap(4, 4);
            image.SetPixel(0, 0, Color.Black);
            image.SetPixel(0, 1, Color.Black);
            image.SetPixel(1, 0, Color.White);
            image.SetPixel(1, 1, Color.White);
            FastBitmap target = new FastBitmap(image);

            try
            {
                for (int x = 0; x < image.Width; x++)
                {
                    for (int y = 0; y < image.Height; y++)
                    {
                        target.Lock();
                        int targetPixel = target.GetPixel(x, y).ToArgb();
                        target.Unlock();

                        Assert.IsTrue(image.GetPixel(x, y).ToArgb() == targetPixel);
                    }
                }
            }
            finally
            {
                target.Unlock();
            }
        }

        [TestMethod]
        public void SetPixelTest()
        {
            Bitmap image = new Bitmap(4, 4);
            image.SetPixel(0, 0, Color.Black);
            image.SetPixel(0, 1, Color.Black);
            image.SetPixel(1, 0, Color.White);
            image.SetPixel(1, 1, Color.White);
            FastBitmap target = new FastBitmap(image);

            try
            {
                target.Lock();

                for (int x = 0; x < image.Width; x++)
                {
                    for (int y = 0; y < image.Height; y++)
                    {
                        target.SetPixel(x, y, Color.Blue);
                    }
                }

                target.Unlock();

                for (int x = 0; x < image.Width; x++)
                {
                    for (int y = 0; y < image.Height; y++)
                    {
                        Assert.IsTrue(image.GetPixel(x, y).ToArgb() == Color.Blue.ToArgb());
                    }
                }
            }
            finally
            {
                target.Unlock();
            }
        }
    }
}
