﻿namespace Petroules.LIEL.UnitTesting
{
    using System.Drawing;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.LIEL;
    
    [TestClass]
    public class RectangleExtensionsTest
    {
        [TestMethod]
        public void AddTest()
        {
            Rectangle rectangle = new Rectangle(0, 0, 100, 100);

            Assert.AreEqual(rectangle, RectangleExtensions.Add(rectangle, 50, 0));
            Assert.AreEqual(rectangle, RectangleExtensions.Add(rectangle, 50, 0));
            Assert.AreEqual(rectangle, RectangleExtensions.Add(rectangle, 100, 100));
            Assert.AreEqual(new Rectangle(0, 0, 100, 101), RectangleExtensions.Add(rectangle, 96, 101));

            Assert.AreEqual(rectangle, RectangleExtensions.Add(rectangle, new Point(50, 0)));
            Assert.AreEqual(rectangle, RectangleExtensions.Add(rectangle, new Point(50, 0)));
            Assert.AreEqual(rectangle, RectangleExtensions.Add(rectangle, new Point(100, 100)));
            Assert.AreEqual(new Rectangle(0, 0, 100, 101), RectangleExtensions.Add(rectangle, new Point(96, 101)));
        }
    }
}
