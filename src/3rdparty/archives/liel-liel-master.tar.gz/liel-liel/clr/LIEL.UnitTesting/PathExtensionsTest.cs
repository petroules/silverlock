﻿namespace Petroules.LIEL.UnitTesting
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.LIEL.IO;

    [TestClass]
    public class PathExtensionsTest
    {
        [TestMethod]
        public void QuoteTest()
        {
            Assert.AreEqual("\"hello\"", PathExtensions.Quote("hello"));
            Assert.AreEqual("\"\"hello\"\"", PathExtensions.Quote("\"hello\""));
            Assert.AreEqual("\"C:\\myfolder\\file.xt\"", PathExtensions.Quote("C:\\myfolder\\file.xt"));
        }
    }
}
