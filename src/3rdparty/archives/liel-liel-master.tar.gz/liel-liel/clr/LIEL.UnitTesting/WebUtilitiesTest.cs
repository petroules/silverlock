﻿namespace Petroules.LIEL.UnitTesting
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.LIEL.Web;

    [TestClass]
    public class WebUtilitiesTest
    {
        [TestMethod]
        public void CreateSeoTitleTest()
        {
            Assert.AreEqual("here-is-the-release-of-our-new-product", WebUtilities.CreateSeoTitle("Here is the release of our new product!"));
            Assert.AreEqual("product-version-3-0", WebUtilities.CreateSeoTitle("Product version 3.0"));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateSeoTitleTestException1()
        {
            WebUtilities.CreateSeoTitle(null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateSeoTitleTestException2()
        {
            WebUtilities.CreateSeoTitle(string.Empty);
        }

        [TestMethod]
        public void IsValidEmailAddressTest()
        {
            Assert.IsFalse(WebUtilities.IsValidEmail("invalid"));
            Assert.IsFalse(WebUtilities.IsValidEmail("@"));
            Assert.IsFalse(WebUtilities.IsValidEmail("!"));
            Assert.IsFalse(WebUtilities.IsValidEmail("h90dhg.com"));

            Assert.IsTrue(WebUtilities.IsValidEmail("jake.@petroules.com"));
            Assert.IsTrue(WebUtilities.IsValidEmail("nsio@8seh."));
            Assert.IsTrue(WebUtilities.IsValidEmail("support@petroules.com"));
            Assert.IsTrue(WebUtilities.IsValidEmail("jake.petroules@petroules.com"));
            Assert.IsTrue(WebUtilities.IsValidEmail("0@petroules.com"));
            Assert.IsTrue(WebUtilities.IsValidEmail("0@0.com"));
            Assert.IsTrue(WebUtilities.IsValidEmail("a@a.aa"));
            Assert.IsTrue(WebUtilities.IsValidEmail("mail-addr@place.com"));
            Assert.IsTrue(WebUtilities.IsValidEmail("bzn9bn8@99.cc"));
            Assert.IsTrue(WebUtilities.IsValidEmail("dgnd9@n0xvk.v"));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void IsValidEmailAddressTestException1()
        {
            WebUtilities.IsValidEmail(null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void IsValidEmailAddressTestException2()
        {
            WebUtilities.IsValidEmail(string.Empty);
        }
    }
}
