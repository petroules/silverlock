#ifndef LIEL_GLOBAL_H
#define LIEL_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(LIEL_LIBRARY)
#  define LIELSHARED_EXPORT Q_DECL_EXPORT
#else
#  define LIELSHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // LIEL_GLOBAL_H
