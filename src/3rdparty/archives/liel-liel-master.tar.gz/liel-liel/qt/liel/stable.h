#ifndef STABLE_H
#define STABLE_H

#include <QtGui>

#ifdef Q_OS_WIN
#include <windows.h>
#elif defined(Q_OS_MAC)
#elif defined(Q_WS_X11)
#endif

#endif // STABLE_H
