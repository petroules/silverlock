#ifndef APPLICATIONINFO_H
#define APPLICATIONINFO_H

#include "liel_global.h"
#include <QtGui>

struct QVersion;

class LIELSHARED_EXPORT ApplicationInfo : public QObject
{
    Q_OBJECT

public:
    /*!
        Enumerates URLs related to the application and its distributing organization.
     */
    enum ApplicationUrl
    {
        /*!
            Specifies the URL of the home page of the organization distributing the application.
         */
        OrganizationHomePage,

        /*!
            Specifies the URL at which donations may be submitted.
         */
        OrganizationDonations,

        /*!
            Specifies the URL of the home page of the application itself.
         */
        ApplicationHomePage,

        /*!
            Specifies the URL at which application help may be found.
         */
        ApplicationHelp,

        /*!
            Specifies the URL at which the application update definition file may be found.
         */
        ApplicationUpdate
    };

    static QString organizationName();
    static void setOrganizationName(const QString &organizationName);
    static QString organizationDomain();
    static void setOrganizationDomain(const QString &organizationDomain);
    static QString applicationName();
    static void setApplicationName(const QString &applicationName);
    static QString unixName();
    static void setUnixName(const QString &unixName);
    static QString bundleId();
    static void setBundleId(const QString &bundleId);
    static QVersion applicationVersion();
    static void setApplicationVersion(const QVersion &applicationVersion);
    static QVersion fileVersion();
    static void setFileVersion(const QVersion &fileVersion);
    static QString copyright();
    static void setCopyright(const QString &copyright);
    static QString trademarks();
    static void setTrademarks(const QString &trademarks);
    static QUrl url(ApplicationUrl urlType);
    static void setUrl(ApplicationUrl urlType, QUrl url);
    static QString platformCode();
    static QString copyrightLink();
    static void initialize();

private:
    explicit ApplicationInfo(QObject *parent = NULL) { Q_UNUSED(parent); }

    static QString s_organizationName;
    static QString s_organizationDomain;
    static QString s_applicationName;
    static QString s_unixName;
    static QString s_bundleId;
    static QVersion s_applicationVersion;
    static QVersion s_fileVersion;
    static QString s_copyright;
    static QString s_trademarks;
    static QMap<ApplicationUrl, QUrl> s_urls;
};

#endif // APPLICATIONINFO_H
