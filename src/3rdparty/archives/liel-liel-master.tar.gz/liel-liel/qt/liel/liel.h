#ifndef LIEL_H
#define LIEL_H

#include "applicationinfo.h"
#include "linuxsysteminfo.h"
#include "platforminformation.h"
#include "qversion.h"
#include "translationutils.h"
#include "windowmanager.h"

#define LIEL_VERSION_STR "1.0"

#endif // LIEL_H
