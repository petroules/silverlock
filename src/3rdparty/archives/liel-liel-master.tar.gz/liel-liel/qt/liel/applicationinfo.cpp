#include "applicationinfo.h"
#include "qversion.h"

QString ApplicationInfo::s_organizationName = QString();
QString ApplicationInfo::s_organizationDomain = QString();
QString ApplicationInfo::s_applicationName = QString();
QString ApplicationInfo::s_unixName = QString();
QString ApplicationInfo::s_bundleId = QString();
QVersion ApplicationInfo::s_applicationVersion = QVersion();
QVersion ApplicationInfo::s_fileVersion = QVersion();
QString ApplicationInfo::s_copyright = QString();
QString ApplicationInfo::s_trademarks = QString();
QMap<ApplicationInfo::ApplicationUrl, QUrl> ApplicationInfo::s_urls = QMap<ApplicationInfo::ApplicationUrl, QUrl>();

QString ApplicationInfo::organizationName()
{
    return ApplicationInfo::s_organizationName;
}

void ApplicationInfo::setOrganizationName(const QString &organizationName)
{
    ApplicationInfo::s_organizationName = organizationName;
}

QString ApplicationInfo::organizationDomain()
{
    return ApplicationInfo::s_organizationDomain;
}

void ApplicationInfo::setOrganizationDomain(const QString &organizationDomain)
{
    ApplicationInfo::s_organizationDomain = organizationDomain;
}

QString ApplicationInfo::applicationName()
{
    return ApplicationInfo::s_applicationName;
}

void ApplicationInfo::setApplicationName(const QString &applicationName)
{
    ApplicationInfo::s_applicationName = applicationName;
}

QString ApplicationInfo::unixName()
{
    return ApplicationInfo::s_unixName;
}

void ApplicationInfo::setUnixName(const QString &unixName)
{
    ApplicationInfo::s_unixName = unixName;
}

/*!
    Gets the identifier of the Mac OS X application bundle.

    The identifier should be in reverse-DNS format, for example: \c com.mycompany.myapp.
 */
QString ApplicationInfo::bundleId()
{
    return ApplicationInfo::s_bundleId;
}

void ApplicationInfo::setBundleId(const QString &bundleId)
{
    ApplicationInfo::s_bundleId = bundleId;
}

QVersion ApplicationInfo::applicationVersion()
{
    return ApplicationInfo::s_applicationVersion;
}

void ApplicationInfo::setApplicationVersion(const QVersion &applicationVersion)
{
    ApplicationInfo::s_applicationVersion = applicationVersion;
}

QVersion ApplicationInfo::fileVersion()
{
    return ApplicationInfo::s_fileVersion;
}

void ApplicationInfo::setFileVersion(const QVersion &fileVersion)
{
    ApplicationInfo::s_fileVersion = fileVersion;
}

QString ApplicationInfo::copyright()
{
    return ApplicationInfo::s_copyright;
}

void ApplicationInfo::setCopyright(const QString &copyright)
{
    ApplicationInfo::s_copyright = copyright;
}

QString ApplicationInfo::trademarks()
{
    return ApplicationInfo::s_trademarks;
}

void ApplicationInfo::setTrademarks(const QString &trademarks)
{
    ApplicationInfo::s_trademarks = trademarks;
}

QUrl ApplicationInfo::url(ApplicationUrl urlType)
{
    return ApplicationInfo::s_urls.value(urlType);
}

void ApplicationInfo::setUrl(ApplicationUrl urlType, QUrl url)
{
    ApplicationInfo::s_urls.insert(urlType, url);
}

QString ApplicationInfo::platformCode()
{
#ifdef Q_OS_WIN
    return "windows";
#elif defined(Q_OS_MAC)
    return "macosx";
#elif defined(Q_OS_LINUX)
    return "linux";
#endif
}

QString ApplicationInfo::copyrightLink()
{
    return ApplicationInfo::copyright().replace(ApplicationInfo::organizationName(),
        QString("<a href=\"http://www.%1\">%2</a>")
            .arg(ApplicationInfo::organizationDomain())
            .arg(ApplicationInfo::organizationName()));
}

void ApplicationInfo::initialize()
{
    QApplication::setOrganizationName(ApplicationInfo::organizationName());
    QApplication::setOrganizationDomain(ApplicationInfo::organizationName());
    QApplication::setApplicationName(ApplicationInfo::applicationName());
    QApplication::setApplicationVersion(ApplicationInfo::applicationVersion().toString());
}
