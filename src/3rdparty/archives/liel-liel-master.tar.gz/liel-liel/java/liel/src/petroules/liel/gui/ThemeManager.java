package petroules.liel.gui;

import javax.swing.*;
import petroules.liel.*;

/**
 * Provides methods to apply and obtain information about Swing look-and-feel themes.
 * @author Jake Petroules
 */
public class ThemeManager
{
	public static String getCurrentTheme()
	{
		return UIManager.getLookAndFeel().toString();
	}
	
	/**
	 * Attempts to apply the theme specified by {@link themeName} and returns
	 * a value indicating whether application of the theme succeeded. Any
	 * exceptions thrown will be printed to the console. 
	 * @param themeName The class name of theme to attempt to apply.
	 */
	public static boolean applyTheme(String themeName)
	{
		try
		{
			UIManager.setLookAndFeel(themeName);
			return true;
		}
		catch (Exception e)
		{
			System.out.println(e);
			return false;
		}
	}
	
	/**
	 * Attempts to apply the Swing look-and-feel native to the underlying platform. This method does
	 * nothing on Mac OS X because the operating system forces its own look-and-feel on the application.
	 */
	public static void applyNativeTheme()
	{
		// Mac OS X forces its own look-and-feel, so we don't need to do anything
		if (SystemInformation.isRunningOnMacOSX())
		{
			return;
		}
		
		// If we're running on Windows, try to use its theme
		if (SystemInformation.isRunningOnWindows())
		{
			ThemeManager.applyTheme("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		else
		{
			// Attempt to set the Linux/GTK theme, and if it fails...
			if (!ThemeManager.applyTheme("com.sun.java.swing.plaf.gtk.GTKLookAndFeel"))
			{
				// Try to use the cross-platform vector LAF, Nimbus (if this fails we end up using Metal, the default LAF)
				ThemeManager.applyTheme("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
			}
		}
	}
}
