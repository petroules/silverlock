﻿namespace Petroules.Synteza.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.Synteza.Math;

    [TestClass]
    public class InformationUnitConverterTest
    {
        [TestMethod]
        public void ConvertTest()
        {
            Assert.AreEqual(1024, InformationUnitConverter.Convert(1, InformationUnit.Gigabyte, InformationUnit.Megabyte));
            Assert.AreEqual(1024, InformationUnitConverter.Convert(1, InformationUnit.Megabyte, InformationUnit.Kilobyte));
            Assert.AreEqual(8 * 1024, InformationUnitConverter.Convert(1, InformationUnit.Kilobyte, InformationUnit.Bit));
            Assert.AreEqual(8 * 1024 / 4, InformationUnitConverter.Convert(1, InformationUnit.Kilobyte, InformationUnit.Nibble));
        }
    }
}
