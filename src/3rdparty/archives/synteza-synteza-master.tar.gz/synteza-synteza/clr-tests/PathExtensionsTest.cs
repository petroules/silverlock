﻿namespace Petroules.Synteza.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.Synteza.IO;

    [TestClass]
    public class PathExtensionsTest
    {
        [TestMethod]
        public void QuoteTest()
        {
            Assert.AreEqual("\"hello\"", PathExtensions.Quote("hello"));
            Assert.AreEqual("\"\"hello\"\"", PathExtensions.Quote("\"hello\""));
            Assert.AreEqual("\"C:\\myfolder\\file.xt\"", PathExtensions.Quote("C:\\myfolder\\file.xt"));
        }
    }
}
