﻿namespace Petroules.Synteza.Tests
{
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.Synteza;
    
    [TestClass]
    public class IListExtensionsTest
    {
        [TestMethod]
        public void SwapTest()
        {
            IList list = new List<int> { 1, 3, 2 };
            IListExtensions.Swap(list, 1, 2);
            Assert.IsTrue(list.Cast<int>().SequenceEqual(new List<int> { 1, 2, 3 }));
        }
    }
}
