﻿namespace Petroules.Synteza.Tests
{
    using System;
    using System.Linq;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.Synteza;
    using Petroules.Synteza.Security;

    [TestClass]
    public class RsaEncryptionTest
    {
        private RsaEncryption encryption;

        public RsaEncryptionTest()
        {
            this.encryption = new RsaEncryption();
        }

        [TestMethod]
        public void EncryptAndDecryptTest()
        {
            Random random = new Random();
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < 1000; i++)
            {
                builder.Append(random.GenerateCharacter());
            }

            try
            {
                Assert.IsTrue(this.EncryptDecrypt(Encoding.UTF8.GetBytes(builder.ToString())));
                Assert.IsTrue(this.EncryptDecrypt(new byte[] { }));
                Assert.IsTrue(this.EncryptDecrypt(new byte[] { 1 }));
                Assert.IsTrue(this.EncryptDecrypt(new byte[] { 1, 2 }));
                Assert.IsTrue(this.EncryptDecrypt(new byte[] { 1, 2, 3 }));
                Assert.IsTrue(this.EncryptDecrypt(new byte[] { 1, 2, 3, 4 }));
                Assert.IsTrue(this.EncryptDecrypt(new byte[] { 1, 2, 3, 4, 5 }));
                Assert.IsTrue(this.EncryptDecrypt(new byte[] { 1, 2, 3, 4, 5, 6 }));
                Assert.IsTrue(this.EncryptDecrypt(new byte[] { 1, 2, 3, 4, 5, 6, 7 }));
                Assert.IsTrue(this.EncryptDecrypt(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 }));
                Assert.IsTrue(this.EncryptDecrypt(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 }));
                Assert.IsTrue(this.EncryptDecrypt(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }));
                Assert.IsTrue(this.EncryptDecrypt(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 }));
                Assert.IsTrue(this.EncryptDecrypt(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 }));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Assert.Fail();
            }
        }

        private bool EncryptDecrypt(byte[] data)
        {
            return this.encryption.Decrypt(this.encryption.Encrypt(data)).SequenceEqual(data);
        }
    }
}
