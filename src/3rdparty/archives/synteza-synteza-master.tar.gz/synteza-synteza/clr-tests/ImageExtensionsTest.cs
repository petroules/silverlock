﻿namespace Petroules.Synteza.Tests
{
    using System.Drawing;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.Synteza;
    
    [TestClass]
    public class ImageExtensionsTest
    {
        [TestMethod]
        public void CountColorsTest()
        {
            Assert.AreEqual(3, ImageExtensions.CountColors(this.GetTestImage()));
        }

        [TestMethod]
        public void CountColorsOfTypeTest()
        {
            Image testImage = this.GetTestImage();

            Assert.AreEqual(2, ImageExtensions.CountColors(testImage, Color.FromArgb(255, 0, 0)));
            Assert.AreEqual(2, ImageExtensions.CountColors(testImage, Color.Red));
            Assert.AreEqual(1, ImageExtensions.CountColors(testImage, Color.Yellow));
            Assert.AreEqual(1, ImageExtensions.CountColors(testImage, Color.Blue));
            Assert.AreEqual(1, ImageExtensions.CountColors(testImage, Color.FromArgb(0, 0, 255)));
        }

        [TestMethod]
        public void ReplaceColorTest()
        {
            Image testImage = this.GetTestImage();
            Bitmap expectedImage = new Bitmap(2, 2);
            expectedImage.SetPixel(0, 0, Color.Red);
            expectedImage.SetPixel(0, 1, Color.FromArgb(255, 0, 0));
            expectedImage.SetPixel(1, 0, Color.Yellow);
            expectedImage.SetPixel(1, 1, Color.Green);

            Image newBitmap = ImageExtensions.ReplaceColor(testImage, Color.Blue, Color.Green);
            Assert.IsTrue(ImageExtensions.CompareColors(expectedImage, newBitmap));
        }

        [TestMethod]
        public void CompareColorsTest()
        {
            Image testImage = this.GetTestImage();

            Bitmap equalImage = new Bitmap(2, 2);
            equalImage.SetPixel(0, 0, Color.Red);
            equalImage.SetPixel(0, 1, Color.Red);
            equalImage.SetPixel(1, 0, Color.Yellow);
            equalImage.SetPixel(1, 1, Color.Blue);

            Bitmap inequalImage = new Bitmap(2, 2);
            inequalImage.SetPixel(0, 0, Color.Red);
            inequalImage.SetPixel(0, 1, Color.FromArgb(255, 0, 0));
            inequalImage.SetPixel(1, 0, Color.Yellow);
            inequalImage.SetPixel(1, 1, Color.Green);

            Assert.IsTrue(ImageExtensions.CompareColors(equalImage, testImage));
            Assert.IsFalse(ImageExtensions.CompareColors(inequalImage, testImage));
        }

        [TestMethod]
        public void ScaleBitmapTest()
        {
            Assert.IsTrue(ImageExtensions.ScaleBitmap(this.GetTestImage(), 4, 4).Size == new Size(8, 8));
            Assert.IsTrue(ImageExtensions.ScaleBitmap(this.GetTestImage(), 0.5f, 0.5f).Size == new Size(1, 1));
        }

        private Image GetTestImage()
        {
            Bitmap image = new Bitmap(2, 2);
            image.SetPixel(0, 0, Color.FromArgb(255, 0, 0));
            image.SetPixel(0, 1, Color.Red);
            image.SetPixel(1, 0, Color.Yellow);
            image.SetPixel(1, 1, Color.FromArgb(0, 0, 255));
            return image;
        }
    }
}
