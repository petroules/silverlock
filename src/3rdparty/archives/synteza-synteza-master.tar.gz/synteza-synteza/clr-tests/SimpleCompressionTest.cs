﻿namespace Petroules.Synteza.Tests
{
    using System.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.Synteza.IO;

    /// <summary>
    /// This is a test class for <see cref="SimpleCompression"/> and is intended to contain all <see cref="SimpleCompression"/> Unit Tests.
    /// </summary>
    [TestClass]
    public class SimpleCompressionTest
    {
        [TestMethod]
        public void CompressTest()
        {
            Assert.IsTrue(new byte[] { 0, 0, 0, 0 }.SequenceEqual(SimpleCompression.Compress(new byte[] { })));
        }

        [TestMethod]
        public void DecompressTest()
        {
            Assert.IsTrue(SimpleCompression.Decompress(new byte[] { 0, 0, 0, 0 }).SequenceEqual(new byte[] { }));
        }

        [TestMethod]
        public void CompressDecompressTest()
        {
            Assert.IsTrue(CompressDecompress(new byte[] { }));
            Assert.IsTrue(CompressDecompress(new byte[] { 0, 0, 0, 0 }));
            Assert.IsTrue(CompressDecompress(new byte[] { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }));
            Assert.IsTrue(CompressDecompress(new byte[] { 1, 231, 1, 5, 1, 61, 3, 15, 53, 15, 13, 123, 12, 123, 3, 1, 1, 31, 51, 12, 12, 1, 3 }));
        }

        private bool CompressDecompress(byte[] data)
        {
            return SimpleCompression.Decompress(SimpleCompression.Compress(data)).SequenceEqual(data);
        }
    }
}
