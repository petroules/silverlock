﻿namespace Petroules.Synteza.Tests
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Text;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.Synteza.IO;
    
    [TestClass]
    public class ChecksumUtilitiesTest
    {
        [TestMethod]
        public void GetChecksumStringTest()
        {
            MemoryStream stream = new MemoryStream();
            ChecksumAlgorithm algorithm = ChecksumAlgorithm.MD5;

            Assert.IsTrue("d41d8cd98f00b204e9800998ecf8427e".Equals(ChecksumUtilities.GetChecksumString(stream, algorithm), StringComparison.OrdinalIgnoreCase));

            byte[] hello = Encoding.ASCII.GetBytes("hello");
            stream.Write(hello, 0, hello.Length);
            stream.Position = 0;

            Assert.IsTrue("5d41402abc4b2a76b9719d911017c592".Equals(ChecksumUtilities.GetChecksumString(stream, algorithm), StringComparison.OrdinalIgnoreCase));
        }

        [TestMethod]
        public void GetChecksumBytesTest()
        {
            MemoryStream stream = new MemoryStream();
            ChecksumAlgorithm algorithm = ChecksumAlgorithm.MD5;

            Assert.IsTrue("d4-1d-8c-d9-8f-00-b2-04-e9-80-09-98-ec-f8-42-7e".Split('-').Select(b => Convert.ToByte(b, 16)).ToArray().SequenceEqual(ChecksumUtilities.GetChecksumBytes(stream, algorithm)));

            byte[] hello = Encoding.ASCII.GetBytes("hello");
            stream.Write(hello, 0, hello.Length);
            stream.Position = 0;

            Assert.IsTrue("5d-41-40-2a-bc-4b-2a-76-b9-71-9d-91-10-17-c5-92".Split('-').Select(b => Convert.ToByte(b, 16)).ToArray().SequenceEqual(ChecksumUtilities.GetChecksumBytes(stream, algorithm)));
        }
    }
}
