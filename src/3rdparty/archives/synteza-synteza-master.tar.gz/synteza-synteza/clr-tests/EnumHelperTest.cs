﻿namespace Petroules.Synteza.Tests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Petroules.Synteza;

    [TestClass]
    public class EnumHelperTest
    {
        [Flags]
        private enum OurTestEnum
        {
            TheSecond = 1,
            TheFirst = 2,
            LastOne = 4
        }

        [TestMethod]
        public void ParseFromStringTest()
        {
            // Test valid constants
            Assert.AreEqual(OurTestEnum.TheFirst, EnumHelper.ParseFromString<OurTestEnum>("TheFirst", null));
            Assert.AreEqual(OurTestEnum.TheSecond, EnumHelper.ParseFromString<OurTestEnum>("TheSecond", null));
            Assert.AreEqual(OurTestEnum.LastOne, EnumHelper.ParseFromString<OurTestEnum>("LastOne", null));

            // Test valid constants with non-null defaults (should be the same as above)
            Assert.AreEqual(OurTestEnum.TheFirst, EnumHelper.ParseFromString<OurTestEnum>("TheFirst", OurTestEnum.TheFirst));
            Assert.AreEqual(OurTestEnum.TheSecond, EnumHelper.ParseFromString<OurTestEnum>("TheSecond", OurTestEnum.TheFirst));
            Assert.AreEqual(OurTestEnum.LastOne, EnumHelper.ParseFromString<OurTestEnum>("LastOne", OurTestEnum.TheFirst));

            // Should return correctly for each, falling back to the default
            Assert.AreEqual(OurTestEnum.TheFirst, EnumHelper.ParseFromString<OurTestEnum>("DOES_NOT_EXIST", OurTestEnum.TheFirst));
            Assert.AreEqual(OurTestEnum.TheSecond, EnumHelper.ParseFromString<OurTestEnum>("DOES_NOT_EXIST", OurTestEnum.TheSecond));
            Assert.AreEqual(OurTestEnum.LastOne, EnumHelper.ParseFromString<OurTestEnum>("DOES_NOT_EXIST", OurTestEnum.LastOne));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ParseFromStringTestException1()
        {
            EnumHelper.ParseFromString<OurTestEnum>(null, null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ParseFromStringTestException2()
        {
            EnumHelper.ParseFromString<OurTestEnum>(string.Empty, null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ParseFromStringTestException3()
        {
            EnumHelper.ParseFromString<OurTestEnum>(" ", null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ParseFromStringTestException4()
        {
            EnumHelper.ParseFromString<OurTestEnum>("DOES_NOT_EXIST", null);
        }

        [TestMethod]
        public void GetSortedListTest()
        {
            // Make sure it works with any constant
            string[] list1 = EnumHelper.GetSortedList(OurTestEnum.TheFirst);
            Assert.AreEqual("TheFirst", list1[0]);
            Assert.AreEqual("LastOne", list1[1]);
            Assert.AreEqual("TheSecond", list1[2]);

            string[] list2 = EnumHelper.GetSortedList(OurTestEnum.TheSecond);
            Assert.AreEqual("TheSecond", list2[0]);
            Assert.AreEqual("LastOne", list2[1]);
            Assert.AreEqual("TheFirst", list2[2]);

            string[] list3 = EnumHelper.GetSortedList(OurTestEnum.LastOne);
            Assert.AreEqual("LastOne", list3[0]);
            Assert.AreEqual("TheFirst", list3[1]);
            Assert.AreEqual("TheSecond", list3[2]);
        }

        [TestMethod]
        public void IsSetTest()
        {
            OurTestEnum var1 = OurTestEnum.LastOne;
            Assert.IsTrue(var1.IsSet(OurTestEnum.LastOne));
            Assert.IsFalse(var1.IsSet(OurTestEnum.TheFirst));
            Assert.IsFalse(var1.IsSet(OurTestEnum.TheSecond));

            OurTestEnum var2 = OurTestEnum.LastOne | OurTestEnum.TheFirst;
            Assert.IsTrue(var2.IsSet(OurTestEnum.LastOne));
            Assert.IsTrue(var2.IsSet(OurTestEnum.TheFirst));
            Assert.IsFalse(var2.IsSet(OurTestEnum.TheSecond));

            OurTestEnum var3 = OurTestEnum.LastOne | OurTestEnum.TheFirst | OurTestEnum.TheSecond;
            Assert.IsTrue(var3.IsSet(OurTestEnum.LastOne));
            Assert.IsTrue(var3.IsSet(OurTestEnum.TheFirst));
            Assert.IsTrue(var3.IsSet(OurTestEnum.TheSecond));
        }

        [TestMethod]
        public void IsNotSetTest()
        {
            OurTestEnum var1 = OurTestEnum.LastOne;
            Assert.IsFalse(var1.IsNotSet(OurTestEnum.LastOne));
            Assert.IsTrue(var1.IsNotSet(OurTestEnum.TheFirst));
            Assert.IsTrue(var1.IsNotSet(OurTestEnum.TheSecond));
            
            OurTestEnum var2 = OurTestEnum.LastOne | OurTestEnum.TheFirst;
            Assert.IsFalse(var2.IsNotSet(OurTestEnum.LastOne));
            Assert.IsFalse(var2.IsNotSet(OurTestEnum.TheFirst));
            Assert.IsTrue(var2.IsNotSet(OurTestEnum.TheSecond));

            OurTestEnum var3 = OurTestEnum.LastOne | OurTestEnum.TheFirst | OurTestEnum.TheSecond;
            Assert.IsFalse(var3.IsNotSet(OurTestEnum.LastOne));
            Assert.IsFalse(var3.IsNotSet(OurTestEnum.TheFirst));
            Assert.IsFalse(var3.IsNotSet(OurTestEnum.TheSecond));
        }

        [TestMethod]
        public void SetTest()
        {
            OurTestEnum var1 = 0;

            // Set a flag
            var1 = var1.Set(OurTestEnum.LastOne);
            Assert.AreEqual(OurTestEnum.LastOne, var1);

            // Set an additional flag
            var1 = var1.Set(OurTestEnum.TheFirst);
            Assert.AreEqual(OurTestEnum.LastOne | OurTestEnum.TheFirst, var1);

            OurTestEnum var2 = OurTestEnum.LastOne;

            // Set two flags at once
            var2 = var2.Set(OurTestEnum.TheFirst | OurTestEnum.TheSecond);
            Assert.AreEqual(OurTestEnum.LastOne | OurTestEnum.TheFirst | OurTestEnum.TheSecond, var2);
        }

        [TestMethod]
        public void ClearTest()
        {
            OurTestEnum var1 = OurTestEnum.LastOne | OurTestEnum.TheFirst | OurTestEnum.TheSecond;

            // Remove a flag
            var1 = var1.Clear(OurTestEnum.LastOne);
            Assert.AreEqual(OurTestEnum.TheFirst | OurTestEnum.TheSecond, var1);

            // Remove an additional flag
            var1 = var1.Clear(OurTestEnum.TheFirst);
            Assert.AreEqual(OurTestEnum.TheSecond, var1);

            OurTestEnum var2 = OurTestEnum.LastOne | OurTestEnum.TheFirst | OurTestEnum.TheSecond;

            // Remove two flags at once
            var2 = var2.Clear(OurTestEnum.TheFirst | OurTestEnum.TheSecond);
            Assert.AreEqual(OurTestEnum.LastOne, var2);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void IsSetTestException()
        {
            0.IsSet(0);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void IsNotSetTestException()
        {
            0.IsNotSet(0);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void SetTestException()
        {
            0.Set(0);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ClearTestException()
        {
            0.Clear(0);
        }
    }
}
