This namespace contains a single class called NativeMethods (which should be split into multiple files as NativeMethods.[Section].cs, without the brackets) and a few other cross-platform utility classes.

Each partial class in this namespace represents a collection of methods imported from native libraries.

Note that ALL NativeMethods partial classes in this namespace should be marked internal.