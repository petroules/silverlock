﻿namespace Petroules.Synteza.Math.Geography
{
    using System;
    using System.Drawing;

    /// <summary>
    /// Provides methods for handling coordinates in a Mercator projection.
    /// </summary>
    public static class MercatorProjection
    {
        /// <summary>
        /// The default range of the projection in pixels.
        /// </summary>
        public const int DefaultRange = 256;

        /// <summary>
        /// Converts a latitude/longitude pair to a point on the Mercator projection.
        /// </summary>
        /// <param name="coordinates">The latitude/longitude pair to convert.</param>
        /// <param name="range">The range of the projection in pixels.</param>
        /// <returns>The point on the Mercator projection equivalent to <paramref name="coordinates"/>.</returns>
        public static MercatorCoordinate LatLngToPoint(LatLng coordinates, int range = MercatorProjection.DefaultRange)
        {
            var point = new MercatorCoordinate(0, 0, range);

            var origin = MercatorProjection.PixelOrigin(range);
            point.X = origin.X + (coordinates.Lng * MercatorProjection.PixelsPerLongitudeDegree(range));

            // NOTE (appleton): Truncating to 0.9999 effectively limits latitude to
            // 89.189.  This is about a third of a tile past the edge of the world tile.
            var siny = MathHelper.Clamp(Math.Sin(MathHelper.DegreesToRadians(coordinates.Lat)), -0.9999, 0.9999);
            point.Y = origin.Y + (0.5 * Math.Log((1 + siny) / (1 - siny)) * -MercatorProjection.PixelsPerLongitudeRadian(range));
            return point;
        }

        /// <summary>
        /// Converts a point on the Mercator projection to a latitude/longitude pair.
        /// </summary>
        /// <param name="point">The point to convert.</param>
        /// <param name="range">The range of the projection in pixels.</param>
        /// <returns>The latitude/longitude pair equivalent to <paramref name="point"/>.</returns>
        public static LatLng PointToLatLng(MercatorCoordinate point, int range = MercatorProjection.DefaultRange)
        {
            var origin = MercatorProjection.PixelOrigin(range);
            var lng = (point.X - origin.X) / MercatorProjection.PixelsPerLongitudeDegree(range);
            var latRadians = (point.Y - origin.Y) / -MercatorProjection.PixelsPerLongitudeRadian(range);
            var lat = MathHelper.RadiansToDegrees(2 * Math.Atan(Math.Exp(latRadians)) - (Math.PI / 2));
            return new LatLng(lat, lng);
        }

        /// <summary>
        /// Gets the pixel origin of a Mercator projection with the specified range.
        /// </summary>
        /// <param name="range">The range of the projection in pixels.</param>
        /// <returns>The origin of the projection.</returns>
        public static PointF PixelOrigin(int range)
        {
            return new PointF(range / 2f, range / 2f);
        }

        /// <summary>
        /// Gets the number of pixels per degree of longitude.
        /// </summary>
        /// <param name="range">The range of the projection in pixels.</param>
        /// <returns>The number of pixels per degree of longitude.</returns>
        public static double PixelsPerLongitudeDegree(int range)
        {
            return range / 360.0;
        }

        /// <summary>
        /// Gets the number of pixels per radian of longitude.
        /// </summary>
        /// <param name="range">The range of the projection in pixels.</param>
        /// <returns>The number of pixels per radian of longitude.</returns>
        public static double PixelsPerLongitudeRadian(int range)
        {
            return range / (2 * Math.PI);
        }
    }
}
