﻿namespace Petroules.Synteza.Math.Geography
{
    using System;
    using System.Globalization;

    /// <summary>
    /// Represents a set of latitude/longitude coordinates.
    /// </summary>
    public struct LatLng : IEquatable<LatLng>
    {
        /// <summary>
        /// The latitude value.
        /// </summary>
        private double lat;

        /// <summary>
        /// The longitude value.
        /// </summary>
        private double lng;

        /// <summary>
        /// Initializes a new instance of the <see cref="LatLng"/> structure.
        /// </summary>
        /// <param name="lat">The latitude value. Will be bound between -90 and 90. <seealso cref="MathHelper.Clamp"/>.</param>
        /// <param name="lng">The longitude value. Will be wrapped between -180 and 180. <seealso cref="MathHelper.Wrap"/>.</param>
        public LatLng(double lat, double lng)
            : this()
        {
            this.Lat = lat;
            this.Lng = lng;
        }

        /// <summary>
        /// Gets the minimum latitude value, inclusive.
        /// </summary>
        public static double MinLat
        {
            get { return -90; }
        }

        /// <summary>
        /// Gets the maximum latitude value, inclusive.
        /// </summary>
        public static double MaxLat
        {
            get { return 90; }
        }

        /// <summary>
        /// Gets the minimum longitude value, inclusive.
        /// </summary>
        public static double MinLng
        {
            get { return -180; }
        }

        /// <summary>
        /// Gets the maximum longitude value, exclusive.
        /// </summary>
        public static double MaxLng
        {
            get { return 180; }
        }

        /// <summary>
        /// Gets or sets the latitude value.
        /// </summary>
        /// <remarks>
        /// Latitude ranges from -90 to 90. As such, the value will be bound between -90 and 90 when set. See <see cref="MathHelper.Clamp"/> for more information.
        /// This is converted to a value along the Y axis on a Mercator projection.
        /// </remarks>
        public double Lat
        {
            get { return this.lat; }
            set { this.lat = MathHelper.Clamp(value, LatLng.MinLat, LatLng.MaxLat); }
        }

        /// <summary>
        /// Gets or sets the longitude value.
        /// </summary>
        /// <remarks>
        /// Longitude ranges from -180 to 180. As such, the value will be wrapped between -180 and 180 when set. See <see cref="MathHelper.Wrap"/> for more information.
        /// This is converted to a value along the X axis on a Mercator projection.
        /// </remarks>
        public double Lng
        {
            get { return this.lng; }
            set { this.lng = MathHelper.Wrap(value, LatLng.MinLng, LatLng.MaxLng); }
        }

        /// <summary>
        /// Determines whether the specified instances are equal.
        /// </summary>
        /// <param name="obj1">The first instance.</param>
        /// <param name="obj2">The second instance.</param>
        /// <returns>See summary.</returns>
        public static bool operator ==(LatLng obj1, LatLng obj2)
        {
            return obj1.Equals(obj2);
        }

        /// <summary>
        /// Determines whether the specified instances are inequal.
        /// </summary>
        /// <param name="obj1">The first instance.</param>
        /// <param name="obj2">The second instance.</param>
        /// <returns>See summary.</returns>
        public static bool operator !=(LatLng obj1, LatLng obj2)
        {
            return !obj1.Equals(obj2);
        }

        /// <summary>
        /// Indicates whether the current object is equal to another object of the same type.
        /// </summary>
        /// <param name="other">Another object to compare to.</param>
        /// <returns>True if the current object is equal to the other parameter; otherwise, false.</returns>
        public bool Equals(LatLng other)
        {
            if (other == null)
            {
                return false;
            }

            return this.Lat == other.Lat && this.Lng == other.Lng;
        }

        /// <summary>
        /// Indicates whether this instance and a specified object are equal.
        /// </summary>
        /// <param name="obj">Another object to compare to.</param>
        /// <returns>True if obj and this instance are the same type and represent the same value; otherwise, false.</returns>
        public override bool Equals(object obj)
        {
            if (obj == null || this.GetType() != obj.GetType())
            {
                return false;
            }

            return this.Equals((LatLng)obj);
        }

        /// <summary>
        /// Returns the hash code for this instance.
        /// </summary>
        /// <returns>A 32-bit signed integer that is the hash code for this instance.</returns>
        public override int GetHashCode()
        {
            return this.Lat.GetHashCode() ^ this.Lng.GetHashCode();
        }

        /// <summary>
        /// Returns a string representation of the latitude/longitude pair.
        /// </summary>
        /// <returns>A string in the form <c>x, y</c> where x is the latitude and y is the longitude.</returns>
        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "{0:R}, {1:R}", this.Lat, this.Lng);
        }
    }
}
