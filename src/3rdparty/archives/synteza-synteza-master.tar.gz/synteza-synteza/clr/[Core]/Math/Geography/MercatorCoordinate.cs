﻿namespace Petroules.Synteza.Math.Geography
{
    using System;
    using System.Globalization;

    /// <summary>
    /// Represents a set of coordinates on a Mercator projection.
    /// </summary>
    public struct MercatorCoordinate : IEquatable<MercatorCoordinate>
    {
        /// <summary>
        /// The X coordinate on the Mercator projection.
        /// </summary>
        private double x;

        /// <summary>
        /// The Y coordinate on the Mercator projection.
        /// </summary>
        private double y;

        /// <summary>
        /// The range of the projection in pixels.
        /// </summary>
        private int range;

        /// <summary>
        /// Initializes a new instance of the <see cref="MercatorCoordinate"/> structure.
        /// </summary>
        /// <param name="x">The X coordinate on the Mercator projection.</param>
        /// <param name="y">The Y coordinate on the Mercator projection.</param>
        /// <param name="range">The range of the projection in pixels.</param>
        public MercatorCoordinate(double x, double y, int range = MercatorProjection.DefaultRange)
            : this()
        {
            // We must set this first or the X and Y won't get set properly
            this.Range = range;
            this.X = x;
            this.Y = y;
        }

        /// <summary>
        /// Gets or sets the X coordinate on the Mercator projection.
        /// </summary>
        public double X
        {
            get { return this.x; }
            set { this.x = MathHelper.Wrap(value, 0, this.Range); }
        }

        /// <summary>
        /// Gets or sets the Y coordinate on the Mercator projection.
        /// </summary>
        public double Y
        {
            get { return this.y; }
            set { this.y = MathHelper.Wrap(value, 0, this.Range); }
        }

        /// <summary>
        /// Gets or sets the range of the projection in pixels.
        /// </summary>
        public int Range
        {
            get { return this.range; }
            set { this.range = value; }
        }

        /// <summary>
        /// Determines whether the specified instances are equal.
        /// </summary>
        /// <param name="obj1">The first instance.</param>
        /// <param name="obj2">The second instance.</param>
        /// <returns>See summary.</returns>
        public static bool operator ==(MercatorCoordinate obj1, MercatorCoordinate obj2)
        {
            return obj1.Equals(obj2);
        }

        /// <summary>
        /// Determines whether the specified instances are inequal.
        /// </summary>
        /// <param name="obj1">The first instance.</param>
        /// <param name="obj2">The second instance.</param>
        /// <returns>See summary.</returns>
        public static bool operator !=(MercatorCoordinate obj1, MercatorCoordinate obj2)
        {
            return !obj1.Equals(obj2);
        }

        /// <summary>
        /// Indicates whether the current object is equal to another object of the same type.
        /// </summary>
        /// <param name="other">Another object to compare to.</param>
        /// <returns>True if the current object is equal to the other parameter; otherwise, false.</returns>
        public bool Equals(MercatorCoordinate other)
        {
            if (other == null)
            {
                return false;
            }

            return this.X == other.X && this.Y == other.Y && this.Range == other.Range;
        }

        /// <summary>
        /// Indicates whether this instance and a specified object are equal.
        /// </summary>
        /// <param name="obj">Another object to compare to.</param>
        /// <returns>True if obj and this instance are the same type and represent the same value; otherwise, false.</returns>
        public override bool Equals(object obj)
        {
            if (obj == null || this.GetType() != obj.GetType())
            {
                return false;
            }

            return this.Equals((MercatorCoordinate)obj);
        }

        /// <summary>
        /// Returns the hash code for this instance.
        /// </summary>
        /// <returns>A 32-bit signed integer that is the hash code for this instance.</returns>
        public override int GetHashCode()
        {
            return this.X.GetHashCode() ^ this.Y.GetHashCode() ^ this.Range;
        }

        /// <summary>
        /// Returns a string representation of the coordinate pair.
        /// </summary>
        /// <returns>A string in the form <c>x, y</c>.</returns>
        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "{0:R}, {1:R}", this.X, this.Y);
        }
    }
}
