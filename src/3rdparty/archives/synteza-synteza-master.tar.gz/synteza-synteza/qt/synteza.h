#ifndef SYNTEZA_H
#define SYNTEZA_H

#include "integratedapplication.h"
#include "linuxsysteminfo.h"
#include "platforminformation.h"
#include "qversion.h"
#include "translationutils.h"
#include "windowmanager.h"
#include "win32/desktopwindowmanager.h"
#include "win32/explorerstyle.h"
#include "win32/integratedmainwindow.h"
#include "win32/jumplist.h"
#include "win32/thumbbar.h"
#include "win32/windowsfileregistration.h"

#define SYNTEZA_VERSION_STR "1.0"

#endif // SYNTEZA_H
