#ifndef WINDOWMANAGER_MAC_P_H
#define WINDOWMANAGER_MAC_P_H

#include "windowmanager.h"

#ifdef Q_WS_MAC
#import <ApplicationServices/ApplicationServices.h>
#import <Cocoa/Cocoa.h>
#endif

#endif // WINDOWMANAGER_MAC_P_H
