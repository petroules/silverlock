#ifndef SYSTEMKEYBOARDREADWRITE_H
#define SYSTEMKEYBOARDREADWRITE_H

#include <QObject>
#include <windows.h>

class SystemKeyboardReadWrite : public QObject
{
    Q_OBJECT

public:
    static SystemKeyboardReadWrite *instance();
    ~SystemKeyboardReadWrite();
    bool connected();
    bool setConnected(bool state);

signals:
    void keyPressed(byte *keysDepressed, DWORD keyPressed);

private:
    // Number of keys supported
    static const int numberKeys = 256;

    static SystemKeyboardReadWrite *uniqueInstance;

    HHOOK keyboardHook;

    SystemKeyboardReadWrite();

    // Identifies hook activity
    static LRESULT CALLBACK keyboardProcedure(int nCode, WPARAM wParam, LPARAM lParam);
};

#endif // SYSTEMKEYBOARDREADWRITE_H
