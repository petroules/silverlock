#include "systemkeyboardreadwrite.h"
#include <QDebug>
#include <iostream>

SystemKeyboardReadWrite* SystemKeyboardReadWrite::uniqueInstance = 0;

SystemKeyboardReadWrite::SystemKeyboardReadWrite()
    : QObject()
{
    this->keyboardHook = NULL;
}

SystemKeyboardReadWrite::~SystemKeyboardReadWrite()
{
    delete uniqueInstance;
}

LRESULT CALLBACK SystemKeyboardReadWrite::keyboardProcedure(int nCode, WPARAM wParam, LPARAM lParam)
{
    if (nCode == HC_ACTION)
    {
        // Check for a key down press
        if (wParam == WM_KEYDOWN)
        {
            KBDLLHOOKSTRUCT *pKeyboard = (KBDLLHOOKSTRUCT*)lParam;

            byte *keysDepressed = new byte[numberKeys];
            if (GetKeyboardState(keysDepressed))
            {
                qDebug().nospace() << (char)pKeyboard->vkCode;

                emit SystemKeyboardReadWrite::instance()->keyPressed(keysDepressed, pKeyboard->vkCode);
            }
        }
        else if (wParam == WM_KEYUP)
        {
        }
    }

    return false;
}

bool SystemKeyboardReadWrite::connected()
{
    return this->keyboardHook;
}

bool SystemKeyboardReadWrite::setConnected(bool state)
{
    if (state)
    {
        if (!this->keyboardHook)
        {
            this->keyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, keyboardProcedure, GetModuleHandle(NULL), 0);
        }

        return this->keyboardHook;
    }
    else
    {
        if (this->keyboardHook)
        {
            UnhookWindowsHookEx(this->keyboardHook);
            this->keyboardHook = NULL;
        }

        return this->keyboardHook;
    }
}

SystemKeyboardReadWrite* SystemKeyboardReadWrite::instance()
{
    if (uniqueInstance == NULL)
    {
        uniqueInstance = new SystemKeyboardReadWrite();
    }

    return uniqueInstance;
}
