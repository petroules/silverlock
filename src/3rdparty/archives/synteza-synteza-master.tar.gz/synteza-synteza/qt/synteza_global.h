#ifndef SYNTEZA_GLOBAL_H
#define SYNTEZA_GLOBAL_H

#include <QtGui>

#if defined(SYNTEZA_LIBRARY)
#  define SYNTEZASHARED_EXPORT Q_DECL_EXPORT
#else
#  define SYNTEZASHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // SYNTEZA_GLOBAL_H
