package com.petroules.synteza;

/**
 * Provides methods to obtain information about the underlying platform, such as the operating system name and version.
 * @author Jake Petroules
 */
public class SystemInformation
{
	/**
	 * Gets a string containing the current operating system's name and version.
	 */
	public static String getOSNameAndVersion()
	{
		return System.getProperty("os.name") + " " + System.getProperty("os.version");
	}
	
	public static String getJavaVersion()
	{
		return System.getProperty("java.version");
	}
	
	public static String getProcessorArchitecture()
	{
		// x86, x86_64, amd64, ppc, sparc, arm
		return System.getProperty("os.arch");
	}
	
	/**
	 * Gets a value indicating whether the application is currently running on a Microsoft Windows operating system.
	 */
	public static boolean isRunningOnWindows()
	{
		return System.getProperty("os.name").toLowerCase().startsWith("windows");
	}
	
	/**
	 * Gets a value indicating whether the application is currently running on an Apple Mac OS X operating system.
	 * @return
	 */
	public static boolean isRunningOnMacOSX()
	{
		return System.getProperty("os.name").toLowerCase().startsWith("mac os x");
	}
}
